<!DOCTYPE html>
<html>
  <?php

  //session_start();
  require_once 'greetinguser.php';


?>

	<button type="button" id="messagebtn" style=" border-color: #44cc7c; width:200px; background-color:#44cc7c; margin-right:4px;margin-left:78%;"class="btn btn-primary"><b>ΕΠΙΣΤΡΟΦΗ</b></button>


    <script>
    document.getElementById("messagebtn").addEventListener("click", function(){
  
    window.location.href = "main.php";
    });
    </script>


<div style="margin: 70px 0 80px 70px; ">

<!-- εισερχόμενα μηνύματα ανα χρήστη -->
<p id="demo"></p>
  <br>
  <hr>
  <br>
<!-- απεσταλμένα μηνύματα ανα χρήστη -->
<p id="demo2"></p>
  <br>
  <hr>
  <br>
  <br>
  <br>
</div> 
  
<!-- Δημιουργία νέου μηνύματος -->
<div style=" border-radius:15px;margin-left:auto; margin-right:auto;padding:15px;width:460px; height: 320px; background-color: #44cc7c;text-align: center;">
<h2 style="letter-spacing: 1px; font-family: arial; color: white;text-shadow: -1px 0 black;">Δημιουργία νέου μηνύματος</h2>
<form id="form3" >
  <div class="form-group">
    <textarea rows="10" cols="45" id="messagetxt" name="messagetxt" placeholder="Εισάγετε το μήνυμα σας..."></textarea>
  </div>
  <button type="button" style="box-shadow: 0 0 4px black;width: 120px; height: 40px; background-color: #44cc7c;color: white;font-weight: bold; border-radius: 8px; border-color: #44cc7c; margin-right: 12px; margin-top: 18px;" onclick="loadXML3()">Αποστολή</button>
  <button type="reset" style="box-shadow: 0 0 4px black;width: 120px; height: 40px; background-color: #44cc7c;color: white;font-weight: bold; border-radius: 8px; border-color: #44cc7c;margin-top: 18px;" >Καθαρισμός</button>
</form>
</div>
<p id="demo3"></p>
<br><br><br><br>
<script>
///// run below ajax functions
loadXML();
loadXML2();

function loadXML() {
    var xhttp = new XMLHttpRequest();
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
          // Typical action to be performed when the document is ready:
          document.getElementById("demo").innerHTML = this.responseText;
        }
    };
    xhttp.open("POST", "usermsgincoming.php", true);
    //xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhttp.send();
}

function loadXML2() {
    var xhttp = new XMLHttpRequest();
    
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
          // Typical action to be performed when the document is ready:
          document.getElementById("demo2").innerHTML = this.responseText;
        }
    };
    xhttp.open("POST", "usermsgsent.php", true);
    //xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhttp.send();
}

function loadXML3() {
    var xhttp = new XMLHttpRequest();
    var data = document.getElementById("messagetxt").value;
    var vars = "messagetxt="+ data;
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
          // Typical action to be performed when the document is ready:
          document.getElementById("demo3").innerHTML = this.responseText;
        }
    };
    xhttp.open("POST", "usermsgcreate.php", true);
    xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhttp.send(vars);
}

</script>
    <footer style="background-color: #1a1b1d; height: 110px; width: 100%;">
      <p style="text-align: center; color:white; padding-top: 60px;">® All rights Reserved by Kyriakos</p>
    </footer>

</html>