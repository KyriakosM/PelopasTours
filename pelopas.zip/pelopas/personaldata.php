<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <style>
    
      input[type="text"]{
        width: 500px;
        } 
	      input[type="password"]{
        width: 500px;
        } 
		input[type="number"]{
        width: 500px;
        } 
        label{
          margin-top: 10px;
        }
    
  </style>
</head>
<body>

 <?php
      
      //session_start();
      require_once 'greetinguser.php';

        //search by session username
        // Prepare our SQL, preparing the SQL statement will prevent SQL injection.
        if ($stmt = $dbconn->prepare('SELECT surname, name, telephone,address,email FROM user
        where user_id=(?)')) {
            $stmt->bind_param('s', $_SESSION['id']);
            $stmt->execute(); 
            $stmt->store_result();
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $count=$stmt->num_rows;
          $stmt->bind_result($u_surname, $u_name, $u_tel,$u_addr,$u_email);
          //statement fetch results
          while ($stmt->fetch()){
            // use column variables from binding
			$user_surname=$u_surname;
			$user_name=$u_name;
            $user_telephone[]=$u_tel;
            $user_address[]=$u_addr;
            $user_email[]=$u_email;
          }
        }       

        $stmt->close();
      ?>
	  
	  
	<button type="button" id="messagebtn" style=" border-color: #44cc7c; width:200px; background-color:#44cc7c; margin-right:4px;margin-left:78%;"class="btn btn-primary"><b>ΕΠΙΣΤΡΟΦΗ</b></button>


    <script>
    document.getElementById("messagebtn").addEventListener("click", function(){
  
    window.location.href = "main.php";
    });
    </script>

<div style="margin: 70px 0 80px 70px; ">
    <!-- tab2 -->

    <p style="font-size: 1.3rem; font-weight: bold;background-color: lightgreen; margin-bottom:55px;margin-right: 70px;">Αλλαγή Password</p>
    
	<form id="form1" >
            <div class="form-group">
              
              <label for="password">Εισάγετε νέο κωδικό password</label>
              <input type="password" style="box-shadow:0 0 9px #44cc7c;"class="form-control" maxlength="260"id="inputpass"  placeholder="New password"><br><br>
              <label for="confpass">Eπιβεβαιώστε τον νέο κωδικό password</label>
              <input type="password" style="box-shadow:0 0 9px #44cc7c;"class="form-control" maxlength="260"id="confpass"  placeholder="Confirm password"><br><br>
			  
			  <button type="button" onclick="loadXML2()" class="btn btn-primary" style="margin-right: 9px; background-color: #44cc7c; font-size: 1.1rem; border-color: #44cc7c;">Ενημέρωση κωδικού</button>
              <button type="reset" class="btn btn-primary"style="margin-right: 9px; background-color: #44cc7c; font-size: 1.1rem; border-color: #44cc7c;">Καθαρισμός</button>
			  <br><br><br>

    <p style="font-size: 1.3rem; font-weight: bold;background-color: lightgreen; margin-bottom:55px;margin-right: 70px;">Αλλαγή στοιχείων επικοινωνίας</p>
			  
              <label for="telephone">Tηλέφωνο</label>
              <input type="number" style="box-shadow:0 0 9px #44cc7c;"class="form-control" maxlength="20" id="inputphone"  value="<?php echo $user_telephone[0] ?>">
              <label for="address">Διεύθυνση</label>
              <input type="text" style="box-shadow:0 0 9px #44cc7c;"class="form-control" maxlength="50" id="inputaddress"  value="<?php echo $user_address [0] ?>"<br>
              <label for="email">Ε-mail</label>
              <input type="text" style="box-shadow:0 0 9px #44cc7c;"class="form-control" maxlength="45" id="inputemail"  value="<?php echo $user_email [0] ?>"<br>
            </div>
            <br>
            <button type="button" onclick="loadXML()"class="btn btn-primary"style="margin-right: 9px; background-color: #44cc7c; font-size: 1.1rem; border-color: #44cc7c;">Ενημέρωση Στοιχείων</button>

          </form>
          <p id="demo"></p>
          <hr>
		  
    <script>

function loadXML() {
    var xhttp = new XMLHttpRequest();
    
    var data02 = document.getElementById("inputphone").value;
    var data03 = document.getElementById("inputaddress").value;
    var data04 = document.getElementById("inputemail").value;
    
    var vars = "inputphone="+data02+"&inputaddress="+data03+"&inputemail="+data04;
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
          // Typical action to be performed when the document is ready:
          document.getElementById("demo").innerHTML = xhttp.responseText;
        }
    };
    
    xhttp.open("POST", "updatedata.php", true);
    xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhttp.send(vars);
}

//update password
function loadXML2() {
    var xhttp = new XMLHttpRequest();
    var data01 = document.getElementById("inputpass").value;
	var data05 = document.getElementById("confpass").value;
        
    var vars = "inputpass="+data01+"&confpass="+data05;
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
          // Typical action to be performed when the document is ready:
          document.getElementById("demo").innerHTML = xhttp.responseText;
        }
    };
    
    xhttp.open("POST", "updatepass.php", true);
    xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhttp.send(vars);
}



    </script> 
   
   
</div>



<footer style="background-color: #1a1b1d; height: 110px; width: 100%;">
      <p style="text-align: center; color:white; padding-top: 60px;">® All rights Reserved by Kyriakos</p>
    </footer>
</body>
</html>
     
          