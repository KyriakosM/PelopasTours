<!DOCTYPE html>
<html>
    <head>
        <title>PELOPAS TRAVEL</title>
        <meta charset="utf-8">
		
    </head>
    <body>
	

      <?php
        require_once 'connection.php';

        //use of html form name parameter to access post data
        if (empty($_POST['inputevent01'])) {
            exit('Παρακαλούμε συμπληρώστε όλα τα πεδία!');
    }
          
          if ($stmt = $dbconn->prepare('SELECT * FROM event where event_name = (?)')) {
            $stmt->bind_param('s', $_POST['inputevent01']);
            $stmt->execute(); 
            $stmt->store_result();
        }

        if ($stmt->num_rows > 0) {
            // bind results
            $count=$stmt->num_rows;
            $stmt->bind_result($e_id,$e_name,$e_desc,$e_cost);
            //statement fetch results
            while ($stmt->fetch()){
              // use column variables from binding
              $event_id[]=$e_id;
              $event_name[]=$e_name;
              $event_desc[]=$e_desc;
              $event_cost[]=$e_cost;
            }
          }else{
            exit('Δεν βρέθηκαν εγγραφές');
          }

        $stmt->close();
      ?>



<!-- -->
<div class="tab">
      <?php
      // checkbox list 
      echo "<div class='input-group' id='myCheckBox'>";
      
      // Εμφάνιση αποτελεσμάτων 
      for ($i=0;$i<$count;$i++){
        echo "<input type='checkbox'  name='examBox[]' value=$event_id[$i]>" . " " . $event_name[$i] ." " .  $event_desc[$i] ." " . $event_cost[$i] ." EUR" ." " ."<br>";
      }
      echo "</div>" ;
        ?>
    </div>
	
	</body>
</html>
	