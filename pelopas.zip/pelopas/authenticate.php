<!DOCTYPE html>
<html>
    <head>
        <title>PELOPAS TRAVEL</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <script src="https://kit.fontawesome.com/yourcode.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@500&display=swap" rel="stylesheet"> 
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@1,700&display=swap" rel="stylesheet"> 
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet"> 
    </head>
    <body>
    	<img style="margin: 40px 0 0 480px; box-shadow:0px 0px 19px black;"   width="300"src="./photos/wrong.jpg" alt=""></div>
    	  <button style="position: absolute; top: 394px; left: 570px;"class="koubi" onclick="window.location.href='http://localhost/pelopas/index.php'">Επιστροφη</button>
		<?php
		//remember data on the server
		session_start();
		//login details
		require_once 'login.php';
		$dbconn = mysqli_connect("$db_hostname", "$db_username", "$db_password", "$db_database");
		if (!$dbconn){
			die('Could not connect: ' . mysqli_error());
		}

		//define charset of the connection for Greek language
		mysqli_set_charset($dbconn, "utf8");
		
		//use of html form name parameter to access post data
		if ( empty($_POST['inputUser']) || empty($_POST['inputPassword']) ) {
				exit('<h2 class="add"><b>Παρακαλώ επιλέξτε ΕΠΙΣΤΡΟΦΗ και συμπληρώσε όλα τα απαιτούμενα πεδία!</b></h2>');

			}
				

		// Prepare our SQL, preparing the SQL statement will prevent SQL injection.
		if ($stmt = $dbconn->prepare('SELECT user_id, username, password,user_type_id FROM user WHERE username = ?')) {
			// Bind parameters (s = string, i = int), in our case the username is a string so we use "s"

			$stmt->bind_param('s', $_POST['inputUser']);
			$stmt->execute();
			// Store the result so we can check if the account exists in the database.
			$stmt->store_result();

		}

		if ($stmt->num_rows > 0) {
			$stmt->bind_result($u_id,$myuser,$password,$usertypeid);
			$stmt->fetch();

			
			// Account exists, now we verify the password.
			// Note: remember to use password_hash in your registration file to store the hashed passwords.
			if (password_verify($_POST['inputPassword'], $password)) {
				// Verification success! User has loggedin!
				// Create sessions so we know the user is logged in, they basically act like cookies but remember the data on the server. 
				session_regenerate_id();
				$_SESSION['loggedin'] = TRUE;
				$_SESSION['name'] = $_POST['inputUser'];
				$_SESSION['id'] = $u_id;
				
				
				//separate views from user and staff
				// redirect force url change
				if ($usertypeid==5){
					header('Location: main.php');
				}elseif($usertypeid==6){
					exit('<h2 class="add"><b>Δεν αναγνωρίζονται τα στοιχεία χρήστη. Παρακαλούμε δοκιμάστε ξανά!</b></h2>');
				}

			} else {
				exit('<h2 class="add"><b>Λανθασμένος κωδικός πρόσβασης. Παρακαλούμε δοκιμάστε ξανά!</b></h2>');
			}
		} else {
			exit('<h2 class="add"><b>Λανθασμένη διεύθυνση email. Παρακαλούμε δοκιμάστε ξανά!</b></h2>');
		}

		$stmt->close();


		?>
		
	</body>
</html>