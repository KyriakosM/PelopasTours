<!DOCTYPE html>
<html>


<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

th {text-align:center;
}

</style>
</head>


  <?php

  //session_start();
  require_once 'connection.php';


// απεσταλμένα μηνυματα απο τον χρήστη
if ($stmt = $dbconn->prepare('select inbound_id,message,date from inbound where user_id = (?);')){
  $stmt->bind_param('i', $_SESSION['id']);
  $stmt->execute(); 
  $stmt->store_result();   

  if ($stmt->num_rows > 0) {
    // bind results
    $count2=$stmt->num_rows;
    $stmt->bind_result($in_id,$msg,$when);
    //statement fetch results
    while ($stmt->fetch()){
      // use column variables from binding
      $inbound_id[]=$in_id;
      $message[]=$msg;
      $date[]=$when;
    }
  }else{
    exit ("Δεν έχετε εξερχόμενα μηνύματα");
  }
}

$stmt->close();

?>

<p><h3>Απεσταλμένα μηνύματα</h3></p>
<!-- απεσταλμένα  ανα χρήστη -->
  <table id="mytable2" >
  <thead>
  <tr><th>Κωδικός<br>μηνύματος</th><th>Κείμενο</th><th>Ημερομηνία</th></tr>
  </thead>
  <?php
  // Εμφάνιση αποτελεσμάτων 
  for ($i=0;$i<$count2;$i++){
    echo "<tr>" ."<td>".  $inbound_id[$i] ."</td>" 
    ."<td>". $message[$i] ."</td>" 
    ."<td>". $date[$i] ."</td></tr>";
  }
  ?>
  </table>
  

<script>


</script>


</html>