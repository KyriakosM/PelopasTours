<!DOCTYPE html>
<html>
    <head>
       
       <title>PELOPAS TRAVEL</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <script src="https://kit.fontawesome.com/yourcode.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@500&display=swap" rel="stylesheet"> 
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@1,700&display=swap" rel="stylesheet"> 
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet"> 
   
    </head>
    <body>
        
        <button style="position: absolute; top: 450px; left: 550px;"class="koubi" onclick="window.location.href='http://localhost/pelopas/index.php'">Επιστροφη</button>

        <?php
        
        //login details
        require_once 'login.php';
        $dbconn = mysqli_connect("$db_hostname", "$db_username", "$db_password", "$db_database");
        if (!$dbconn){
            die('Could not connect: ' . mysqli_error());
        }

        //define charset of the connection for Greek language
        mysqli_set_charset($dbconn, "utf8");
        //use of html form name parameter to access post data

        ///// mike changes /////    
        if (empty($_POST['inputUser'])  || empty($_POST['inputPassword']) || empty($_POST['inputSurname']) || empty($_POST['inputName']) 
            || empty($_POST['inputAddress']) || empty($_POST['inputEmail']) || empty($_POST['inputTelephone']) ){
                exit('<img style="margin: 40px 0 0 480px; box-shadow:0px 0px 19px black;"   width="300"src="./photos/wrong.jpg" alt=""><br><br>
				<h2 class="add"><b>Παρακαλούμε επιλέξτε ΕΠΙΣΤΡΟΦΗ<br>και συμπληρώστε όλα τα απαιτούμενα πεδία. </b></h2>');
        }
		
		if ($_POST['inputPassword'] != $_POST['inputPassconfirm']) {
            exit('<img style="margin: 40px 0 0 480px; box-shadow:0px 0px 19px black;"   width="300"src="./photos/wrong.jpg" alt=""><br><br>
			<h2 class="add"><b>Δεν έχετε επιβεβαιώσει σωστά τον κωδικό Password.<br>Δοκιμάστε ξανα! </b></h2>');
        }
		
		if (preg_match("/[^a-zΑ-Ζ\s-]/i", ($_POST['inputName']))){
			exit('<img style="margin: 40px 0 0 480px; box-shadow:0px 0px 19px black;"   width="300"src="./photos/wrong.jpg" alt=""><br><br>
			<h2 class="add"><b>Δεν επιτρέπονται αριθμητικά ψηφία<br>τoνισμός ή άλλα σύμβολα στο Όνομα.</b></h2>'); 
		}
		if (preg_match("/[^a-zΑ-Ζ\s-]/i", ($_POST['inputSurname']))){
			exit('<img style="margin: 40px 0 0 480px; box-shadow:0px 0px 19px black;"   width="300"src="./photos/wrong.jpg" alt=""><br><br>
			<h2 class="add"><b>Δεν επιτρέπονται αριθμητικά ψηφία<br>τoνισμός ή άλλα σύμβολα στο Επίθετο.</b></h2>'); 
		}
				
		if (!filter_var(($_POST['inputEmail']), FILTER_VALIDATE_EMAIL)) {
			exit('<img style="margin: 40px 0 0 480px; box-shadow:0px 0px 19px black;"   width="300"src="./photos/wrong.jpg" alt=""><br><br>
			<h2 class="add"><b>H διεύθυνση Ε-mail δεν είναι έγκυρη!</b></h2>');
		}
		
		if(strlen($_POST['inputTelephone']) != 10){
			exit('<img style="margin: 40px 0 0 480px; box-shadow:0px 0px 19px black;"   width="300"src="./photos/wrong.jpg" alt=""><br><br>
			<h2 class="add"><b>Εισάγετε 10-ψήφιο τηλεφωνικό αριθμό.</b></h2>');  
		}
		
        // check if user already exists 
        // prevent SQL injection
        if ($stmt = $dbconn->prepare('SELECT username FROM user WHERE username = ?')) {
            // Bind parameters (s = string, i = int), in our case the username is a string so we use "s"
            $stmt->bind_param('s', $_POST['inputUser']);
            $stmt->execute();
            // Store the result so we can check if the account exists in the database.
            $stmt->store_result();
        }

        if ($stmt->num_rows > 0) {
            exit('<img style="margin: 40px 0 0 480px; box-shadow:0px 0px 19px black;"   width="300"src="./photos/wrong.jpg" alt=""><br>
			<h2 class="add"><b>Το συγκεκριμένο όνομα χρήστη χρησιμοποιείται ήδη. <br>Παρακαλούμε επιλέξτε ΕΠΙΣΤΡΟΦΗ  και επιλέξτε<br>διαφορετικό όνομα χρήστη για την εγγραφή σας.<br>
                </b></h2>');
            

        }else{
            // insert new user to database
            if ($stmt = $dbconn->prepare('insert into user(username,password,user_type_id, surname, name, address, email, telephone) 
                values (?,?,?,?,?,?,?,?)')) {
                // hash password function, how to store into mysql database
                $hash = password_hash($_POST['inputPassword'], PASSWORD_DEFAULT);
                // Bind parameters (s = string, i = int), in our case the username is a string so we use "s"
                //Παίρνουμε ώς δεδομένο ότι απο αυτή τη λειτουργία καταχωρούνται σταθερά μονο χρήστες
                //το προσωπικό μπορεί να καταχωρηθεί μόνο απο κάποιον που είναι ήδη staff στη βάση δεδομένων
                // ετσι διατηρούμε ένα πεδίο login για όλους και ανάλογα με την κατηγορία 5 για χρήστη ή 6 για staff
                // θα οδηγείται στα αντίστοιχα views
                $usertype=5;//user type id
                $stmt->bind_param('ssissssi', $_POST['inputUser'],$hash,$usertype, $_POST['inputSurname'], $_POST['inputName'], $_POST['inputAddress'], $_POST['inputEmail'], $_POST['inputTelephone']);
                $stmt->execute();
                // Store the result so we can check if the account exists in the database.
                $stmt->store_result();
                exit('<h2 class="add"><b>Ολοκληρώθηκε η εγγραφή σας στο σύστημα!<br> 
                    Παρακαλούμε, επιλέξτε ΕΠΙΣΤΡΟΦΗ και Είσοδο για μέλη από την αρχική μας σελίδα.</b></h2>');
                echo "<pre>
                     
                    </pre>";
            }
        }

        $stmt->close();


        ?>

    </body>
</html>