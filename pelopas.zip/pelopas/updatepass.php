<?php
    
    //session_start();
    require_once 'connection.php';

	$confpass = "";

    if (empty($_POST['inputpass'])) {
        exit('Παρακαλoύμε συμπληρώστε όλα τα πεδία!');
    }
	
	if ($_POST['inputpass'] != $_POST['confpass']) {
        exit('Δεν έχετε επιβεβαιώσει σωστά τον κωδικό Password. Δοκιμάστε ξανα!');
    }
	
    //update by session username
    // Prepare our SQL, preparing the SQL statement will prevent SQL injection.
    if ($stmt = $dbconn->prepare('UPDATE user SET password = (?)
        where user_id=(?)')){
        
            $hash = password_hash($_POST['inputpass'], PASSWORD_DEFAULT);
            $stmt->bind_param('si',$hash, $_SESSION['id']);
            $stmt->execute();    
            exit('O κωδικός password άλλαξε!');
        
        }else{
            exit('Δεν ολοκληρώθηκε η αλλαγή του κωδικού password. Δοκιμάστε ξανα!');
        }

    $stmt->close();
?>

    
    
          