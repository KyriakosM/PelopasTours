<!DOCTYPE html>
<html>
         
    <head>
    
        <title>PELOPAS TRAVEL</title>
        <link rel="stylesheet" href="style.css">
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> 
        
    </head>
  <body id="staffbody">          
    
  <div class="container">
  <div class="newacc1">
        <h4 id="h4staff">Εξουσιοδοτημένο προσωπικό μόνο!</h4>
    <form id="form1"style="margin:0" method="post" action="authstaff.php">
            <div class="form-group">
              <label style=" text-shadow: 1px 1px black;margin-top:30px;font-size:1.1rem; font-weight:bold; color:white;"for="inputEmail">Όνομα χρήστη:</label>
              <input type="text" style="width:315px" class="form-control" id="inputUser" name="inputUser" placeholder="username">
            </div>
            <div class="form-group">
              <label style="margin-top:8px; text-shadow: 1px 1px black;  font-size:1.14rem; font-weight:bold; color:white;" for="inputPassword">Κωδικός:</label>
              <input type="password"style="width:315px" class="form-control" id="inputPassword" name="inputPassword" placeholder="password">
            </div>
           
            <button type="submit" class="koubi" style="width: 100px; margin:17px 15px 14px 0;"class="btn btn-primary">Εiσοδος</button>
            <button type="reset" class="koubi" style="width: 130px; margin-top:17px;  margin-right:14px;"class="btn btn-secondary">Καθαρισμoς</button>
            <br><br><a href="index.php" class="koubi a"style="margin-top:25px;">Επιστροφη</a>

            <!-- <button class="koubi" onclick="window.location.href='http://localhost/pelopas/index.php'">Επιστροφη</button> -->
            
          </form>
          <br>
        </div>
    </div>
          
		</div>
		
    </body>
</html>