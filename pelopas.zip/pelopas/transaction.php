<!DOCTYPE html>
<html>
  <?php

  //session_start();
  require_once 'greetinguser.php';

  $aux = json_decode($_COOKIE["mystorage"],true);
    // use first column of cookie only
  for ($x = 0; $x < count($aux); $x++) {
    $eventcol[$x] = $aux[$x][0] ;
    $quantcol[$x] = $aux[$x][1] ;
    
  }

  $datetime = date('Y-m-d H:i:s');
// δημιουργία νέας παραγγελίας οπου θα υπάγονται οι γραμμές παραγγελίας
if ($stmt = $dbconn->prepare('insert into customer_order(user_id, customer_order_date) values (?,?);')){
    $stmt->bind_param('is', $_SESSION['id'], $datetime);
    $stmt->execute(); 
       
}

// επιστρέφει την πιο πρόσφατη παραγγελία του συγκεκριμένου χρήστη για να χρησιμοποιηθεί κατα τη νέα καταχώρηση
if ($stmt = $dbconn->prepare('select customer_order.customer_order_id 
from customer_order
inner join user 
on user.user_id = customer_order.user_id
where user.user_id = (?)
and customer_order.customer_order_id = (select max(customer_order.customer_order_id) from customer_order);')){
    $stmt->bind_param('i', $_SESSION['id']);
    $stmt->execute();   
    $stmt->store_result(); 
    $stmt->bind_result($custord_id);
    $stmt->fetch();
    
}

// δημιουργία νέας γραμμής ανα κωδικό προϊόντος, δέχεται τον πίνακα επιλογών του χρήστη καθώς και τη ποσότητα που ζητήθηκε 
foreach ($aux as $row){
    if ($stmt = $dbconn->prepare("insert into order_line(customer_order_id,event_id,event_quant) values ('$custord_id',?,?)")){
        
        $stmt->bind_param("ss", $row[0], $row[1]);
        $stmt->execute(); 
        $stmt->close();
    }
    }
    
    
// τοποθετούμε το κόστος για κάθε event ανα γραμμή παραγγελίας
foreach ($eventcol as $row){

    if ($stmt = $dbconn->prepare("UPDATE order_line SET event_cost = (select event_cost from event where event.event_id = ?) 
    WHERE (customer_order_id = '$custord_id') and (event_id = ?);")){
        //pass the same variable
        $stmt->bind_param("ss", $row, $row);
        $stmt->execute(); 
        $stmt->close();
    }
    }

   
// πολλαπλασιασμός κόστους και ποσότητας ανα γραμμή παραγγελίας
foreach ($eventcol as $row){
    if ($stmt = $dbconn->prepare(" UPDATE order_line 
    SET total_cost = (select event_cost from order_line where customer_order_id = '$custord_id' and event_id = ?) 
    *  (select event_quant from order_line where customer_order_id = '$custord_id' and event_id = ?)
    WHERE customer_order_id = '$custord_id' and event_id = ? ")){
        //pass the same variable
        $stmt->bind_param("sss", $row, $row, $row);
        $stmt->execute(); 
        $stmt->close();
    }
    }
    
// αθροισμα του συνολικού κόστους των γραμμών παραγγελίας
foreach ($eventcol as $row){
    if ($stmt = $dbconn->prepare("UPDATE customer_order set order_total_cost =
    (select sum(total_cost) from order_line where customer_order_id = '$custord_id')
    where customer_order_id = '$custord_id' ")){
        
        $stmt->execute(); 
        $stmt->close();
    }
    }
  ?>



<script>
/////////////////////////////////////////////
function setCookie(cname, cvalue, exdays) {
      var d = new Date();
      d.setTime(d.getTime() + (exdays*24*60*60*1000));
      var expires = "expires="+ d.toUTCString();
      document.cookie = cname + "=" + cvalue + ";" + expires  ;
    }

    function getCookie(cname) {
      var name = cname + "=";
      var decodedCookie = decodeURIComponent(document.cookie);
      var ca = decodedCookie.split(';');
      for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }
    ////////////////////////////
    // εφόσον ολοκληρωθεί ο κώδικας της php τότε εκτελούμε τις παρακάτω ενέργειες
    alert("Η συναλλαγή ολοκληρώθηκε.");
    //empty cookies
    mystorage=[];
    setCookie("mystorage", JSON.stringify(mystorage), 1);
    // return to main page
    window.location.href = "main.php";
</script>


</html>