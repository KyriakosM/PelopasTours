
<!DOCTYPE html>
<html>


<?php
session_start();
session_destroy();
?>

<script> 
alert("Έπιτυχής εξοδος από την εφαρμογή. Σας ευχαριστούμε!");
window.location.href = "index.php";
</script>

</html> 