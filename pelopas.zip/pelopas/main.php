<!DOCTYPE html>
<html>
<head>
        <title>PELOPAS TRAVEL</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <style>
          
          .all{
            width: 90%;
            margin-left: 5%;
            margin-top: 0px;
            border-left: 2px solid #44cc7c;
            border-right: 2px solid #44cc7c;
            padding: 52px;
            box-shadow: 0 0 25px #44cc7c;
          }

        </style>
    </head>
<!-- document onload χρησιμοποιείται απο την js -->
<body>
  <a id="top"></a>
    <?php
     
      //session_start();
      require_once 'greetinguser.php';

        if ($stmt = $dbconn->prepare('SELECT * FROM event')) {
          $stmt->execute(); 
          $stmt->store_result();
        }

        if ($stmt->num_rows > 0) {
          $count=$stmt->num_rows;
          $stmt->bind_result($e_id,$e_name,$e_desc,$e_cost);
          //statement fetch results
          while ($stmt->fetch()){
            // use column variables from binding
            $event_id[]=$e_id;
            $event_name[]=$e_name;
            $event_desc[]=$e_desc;
            $event_cost[]=$e_cost;
          }
        }

        //rating query
        if ($stmt = $dbconn->prepare('SELECT user.username, event.event_name, rating.rate, rating.description, rating.date 
        from rating
        inner join user 
        on user.user_id = rating.user_id
        inner join event 
        on event.event_id = rating.event_id')) {
          $stmt->execute(); 
          $stmt->store_result();
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $counttwo=$stmt->num_rows;
          $stmt->bind_result($u_user,$e_name2,$r_rate,$r_desc,$r_date);
          //statement fetch results
          while ($stmt->fetch()){
            // use column variables from binding
            $user_username[]=$u_user;
            $event_name2[]=$e_name2;
            $rating_rate[]=$r_rate;
            $rating_desc[]=$r_desc;
            $rating_date[]=$r_date;
          }
        }
          

        $stmt->close();
      ?>


	
	<div class="all">
    <!----------- Cards ----------->
<a style=" text-shadow: 0 0 20px black; font-weight:bold;display:inline-block; color:green; margin-top: -35px;margin-left:auto;margin-right:auto; letter-spacing: 1px;" href="#epiloges"><span style='font-size:25px;'>&#8681;</span>Επιλέξτε άμεσα τον επόμενο προορισμό σας εδώ! </a>
<form id="form1">
			
			<div class="form-group">
			
			<label style="letter-spacing: 1px; font-size: 1.05rem;text-decoration: underline; text-decoration-color: #44cc7c; font-weight: bold;" >Δείτε τα μηνύματά σας εδώ</label><br>
			<button type="button" id="messagebtn" style=" border-color: #44cc7c; width:200px; background-color:#44cc7c; margin-right:4px;"class="btn btn-primary"><b>Μηνύματα</b></button>
            <br><br><br><br>
			
	          <label for="inputevent" style="letter-spacing: 1px; font-size: 1.05rem;text-decoration: underline; text-decoration-color: #44cc7c; font-weight: bold;" >Γρήγορη αναζήτηση προορισμού</label>
			  <p>Δείτε αν ο προορισμός που σας ενδιαφέρει, συμπεριλαμβάνεται στον τρέχοντα κατάλογό μας.</p>
              <input type="text" style="width:40%; min-width:250px;"class="form-control" id="inputevent01" name="inputevent" placeholder="Όνομα προορισμού">
            </div>
             
            <button type="button"style=" border-color: #44cc7c; width:200px; background-color:#44cc7c; margin-right:4px;"class="btn btn-primary" onclick="loadXML()"><b>Αναζήτηση</b></button>
            <button type="reset" class="btn btn-secondary"><b>Καθαρισμός</b></button>
          <p id="demo"></p>

</form>

  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <!-- ---------------------------------- -->
  <div class="card-group" style="margin-top: -60px; box-shadow: 0 0 15px #44cc7c;">
  <div class="card">
    <img src="./photos/tripoli1.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Τρίπολη</h5>
      <p class="card-text">Γνωρίστε αυτό το ΣΚ την πιο όμορφη πόλη της Πελοποννήσου.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
    <a href="#tri" onMouseOver="this.style.color='green'"onMouseOut="this.style.color='white'" style="background-color: #44cc7c; border-color: #44cc7c;"class="btn btn-primary"><b>More</b> <span style='font-size:14px;'>&#10010;</span></a>
  </div>
  <div class="card">
    <img src="./photos/vitina3.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Βιτίνα</h5>
      <p class="card-text">Περιηγηθείτε στα μαγευτικά μονοπάτια, εντός και εκτός της πόλης!</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
    <a href="#vit" onMouseOver="this.style.color='green'"onMouseOut="this.style.color='white'"style="background-color: #44cc7c; border-color: #44cc7c;" class="btn btn-primary"><b>More</b> <span style='font-size:14px;'>&#10010;</span></a>

  </div>
  <div class="card">
    <img src="./photos/kalavrita2.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Καλάβρυτα</h5>
      <p class="card-text">Ελάτε μαζί μας για snowboard στα αξεπέραστης φυσικής ομορφιάς βουνά των Καλαβρύτων..</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
    <a href="#kalav" onMouseOver="this.style.color='green'"onMouseOut="this.style.color='white'"style="background-color: #44cc7c; border-color: #44cc7c;"class="btn btn-primary"><b>More</b> <span style='font-size:14px;'>&#10010;</span></a>

  </div>
  <div class="card">
    <img src="./photos/kalamata1.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Καλαμάτα</h5>
      <p class="card-text">Μια υπέροχη μονοήμερη εκδρομή στους πανέμορφους αμπελώνες της Καλαμάτας.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
    <a href="#kal" onMouseOver="this.style.color='green'"onMouseOut="this.style.color='white'"class="btn btn-primary" style="background-color: #44cc7c; border-color: #44cc7c;"><b>More</b> <span style='font-size:14px;'>&#10010;</span></a>

  </div>

</div>
  
      <br>
      <br>
      
      
     <hr style="height: 10px;margin-top:15px; margin-bottom:0px;border: 0;box-shadow: 0 10px 10px -10px #8c8b8b inset;">
      <br><br>
      <div style="text-align: center; margin-bottom: 50px; margin-top:-100px"><img style="border-radius:130px;box-shadow: 0 0 60px #44cc7c;margin-top:100px"width="197"src="./photos/logostaff.png" ></div>
      <a id="kal"></a>
      <hr style="height: 10px;margin-top:12px;border: 0;margin-bottom:40px;box-shadow: 0 10px 10px -10px #8c8b8b inset;">
      <div class="picfirst"><p >Kαλαμάτα</p></div>   
      <p class="ps">Εμπνευσμένα street happenings, ολικό ξενοδοχειακό lifting και νέες φιλόδοξες μονάδες στα σκαριά,
        εστιατόρια και στέκια που αγκαλιάζουν επιτυχημένα τις νέες τάσεις, παραλίες για κάθε διάθεση, και με την άμμο κυριολεκτικά
        στα πόδια της! Η Καλαμάτα εξελίσσεται σε μια από τις ομορφότερες και πιο ζωντανές πόλεις της Ελλάδας. Δεν ξέρουμε
        αν θα κερδίσει τον τίτλο της Πολιτιστικής Πρωτεύουσας της Ευρώπης για το 2021 (είναι σοβαρό φαβορί), σίγουρα όμως
        είναι η πιο ανερχόμενη πόλη του ελληνικού καλοκαιριού. </p>
        <div class="bigpic"><img src="./photos/summer.jpg" alt=""></div>
        <div class="picrow">
        <img src="./photos/kalamata1.jpg" alt="">
        <img src="./photos/kalamata2.jpg" alt="">
        <img src="./photos/kalamata3.jpg" alt="">
        <img src="./photos/kalamata4.jpg" alt="">
      </div>
          <p class="ps">Αν ένα στοιχείο της προσωπικότητας της Καλαμάτας είναι ο έξω καρδιά χαρακτήρας της,
             ένα άλλο είναι η σταδιακή διαμόρφωση ενός νέου ταξιδιωτικού (και όχι μόνο) προφίλ. Με τον αέρα της φιναλίστ 
             πλέον, μαζί με την Ελευσίνα και τη Ρόδο, στην κούρσα της διεκδίκησης για τον τίτλο της Πολιτιστικής 
             Πρωτεύουσας της Ευρώπης για το 2021, η πρωτεύουσα της Μεσσηνίας ωριμάζει όμορφα χάρη σε συντονισμένες 
             κινήσεις: ο νέος δρόμος που μας φέρνει στην πόρτα της σε μόλις 2,5 ώρες, το διεθνές –πλέον– αεροδρόμιό 
             της (προς το οποίο πετά από φέτος και η British Airways), το λιμάνι της που αποτελεί σταθμό για κρουαζιέρες,
            το εκτενές δίκτυο ποδηλατόδρομων που έχουν αγκαλιάσει κάτοικοι και επισκέπτες, ακόμα και οι πτήσεις με
             αερόστατο που ξεκίνησαν στα μέσα Μαΐου και θα διαρκέσουν όλο το καλοκαίρι. </p>   
             <a href="#epiloges" style="border-radius:6px;opacity:0.7;display: inline-block;width:43px;height: 25px; background-color: #44cc7c; color: white;"><span style="font-size: 0.9rem; object-fit: contain; margin-left: 5px;"><b>Cart</b></span></a>      
<div class="backtop"> 
    <a href="#top"><span >Back to top </span></a></div>
        <br>
      <hr style="height: 10px;margin-top:15px; margin-bottom:-20px;border: 0;box-shadow: 0 10px 10px -10px #8c8b8b inset;">
        <br><br>
      <div style="text-align: center; margin-bottom: 50px; "><img style="border-radius:130px;box-shadow: 0 0 60px #44cc7c;"width="197"src="./photos/logostaff.png" alt=""></div>
      <a id="vit"></a>
      <hr style="height: 10px;margin-top:12px;border: 0;margin-bottom:40px;box-shadow: 0 10px 10px -10px #8c8b8b inset;">
      <div  class="picfirst"><p>Bυτίνα</p></div>   
      <p class="ps">Με το που θα πέσουν τα πρώτα φύλλα, μαζί με τη Δημητσάνα, γίνονται οι απόλυτες πρωταγωνίστριες του Σαββατοκύριακου. 
        Καλογυαλισμένα SUV καλύπτουν κάθε σημείο τους με τους επισκέπτες να αποχωρίζονται για λίγο το τζακούζι της σουίτας τους για να γευτούν 
        μαγειρευτά στη γάστρα και ντόπιο κρασί. Ξαναζούμε εκείνο τον πρώτο ρομαντικό περίπατο στον περίφημο Δρόμο της Αγάπης, κάτω από
        αιωνόβια πλατάνια και σφενδάμους, με το τιτίβισμα των πουλιών να μας συνοδεύει. Το παλιό νυφοπάζαρο της Βυτίνας ξεκινά από το
        δημοτικό σχολείο και φτάνει ως τους πρόποδες του Μαινάλου στην κατεύθυνση της Αλωνίσταινας. Η διαδρομή δεν είναι μεγάλη αλλά
        άκρως ρομαντική. Εδώ άλλωστε γινόταν και το “νυφοπάζαρο” της περιοχής με τους νέους να ανταλλάσσουν βλέμματα και μηνύματα 
        αγάπης, σύμφωνα πάντα με τα αυστηρά ήθη της εποχής. </p>
        <div class="bigpic"><img src="./photos/vit.jpg" alt=""></div>
        <div class="picrow">
        <img src="./photos/vitina1.jpg" alt="">
        <img src="./photos/vitina2.jpg" alt="">
        <img src="./photos/vitina3.jpg" alt="">
        <img src="./photos/vitina4.jpg" alt="">
      </div>
          <p class="ps">Χτισμένη στα 1.033 μέτρα υψόμετρο, η Βυτίνα απλώνεται νωχελικά μέσα στο Μαίναλο,
     περικυκλωμένη από το ελατόδασός του. Φημίζεται για το υγιεινό κλίμα και το αλπικό τοπίο της και, εξαιτίας
     της θέσης της, αποτελεί ιδανικό ορμητήριο για γνωριμία με την ορεινή Αρκαδία. Σύμφωνα με την επικρατέστερη
     εκδοχή, χτίστηκε το 350 μ.Χ., μετά τη διάλυση της αρχαίας αρκαδικής κώμης του Μεθυδρίου. Το όνομά της,
     σύμφωνα με μια εκδοχή, προέρχεται από τη λέξη βυθός, επειδή η παλιά κωμόπολη ήταν χτισμένη στο βάθος
    μιας λεκάνης τριγυρισμένης από λόφους. Μια άλλη εκδοχή δέχεται ότι το όνομά της οφείλεται στους
    Σλάβους που είχαν κατοικήσει την περιοχή και αργότερα εξελληνίσθηκαν. Στην Επανάσταση του 1821,
    η Βυτίνα είχε αναγνωριστεί ως "βακούφιο" και θεωρούταν τόπος ιερός. Αργότερα, αποτέλεσε εμπορικό
    κέντρο ολόκληρης της περιοχής, με σημαντικό παζάρι. Μάλιστα, υπήρχε υποκατάστημα της Τράπεζας 
    Αθηνών καθώς και Δασοκομική Σχολή. Τα παλαιότερα χρόνια λειτουργούσαν αρκετά εργαστήρια ξυλοτεχνίας 
    και υφαντουργεία. Αξιομνημόνευτοι είναι οι "Αργαλειοί" που λειτούργησαν την περίοδο του 1928, και στους
    οποίους οι νέες της περιοχής παρήγαγαν εξαιρετικά υφαντά. Σήμερα, η Βυτίνα κρατά τα πρωτεία στην τουριστική 
    κίνηση της Αρκαδίας, με προσεγμένους ξενώνες, καλά εστιατόρια που σερβίρουν ντόπιες σπεσιαλιτέ και το χιονοδρομικό
     κέντρο του Μαινάλου σε απόσταση αναπνοής.  </p>
     <a href="#epiloges" style="border-radius:6px;opacity:0.7;display: inline-block;width:43px;height: 25px; background-color: #44cc7c; color: white;"><span style="font-size: 0.9rem; object-fit: contain; margin-left: 5px;"><b>Cart</b></span></a>
<div class="backtop"> 
    <a href="#top"><span >Back to top </span></a></div>
 <br><br>
      <hr style="height: 10px;margin-top:15px; margin-bottom:-20px;border: 0;box-shadow: 0 10px 10px -10px #8c8b8b inset;">
      <br><br>
      <br>
      <div style="text-align: center; margin-bottom: 50px; "><img style="border-radius:130px;box-shadow: 0 0 60px #44cc7c;"width="197"src="./photos/logostaff.png" alt=""></div>
      <a id="kalav"></a>
<hr style="height: 10px;margin-top:12px;border: 0;margin-bottom:40px;box-shadow: 0 10px 10px -10px #8c8b8b inset;">
      <div class="picfirst"><p>Kαλάβρυτα</p></div>   
      <p class="ps">Τα Καλάβρυτα αποτελούν έναν μοναδικό προορισμό συνδυάζοντας πολλές και διαφορετικές
         επιλογές όλο το χρόνο για κάθε λογής επισκέπτη.Ακριβώς απέναντι ο Οδοντωτός, σας περιμένει… επιβιβαστείτε
        σε ένα από τα βαγόνια του και αφήστε τον να σας κάνει μία διαφορετική ξενάγηση στο φαράγγι του Βουραϊκού
         που όμοια της δεν υπάρχει!<br>Ο μύθος αναφέρει τρείς αδερφές την Ιφινόη, την Λυσίππη και την Ιφιάνασσα, 
         αυτό  όμως  που κάνει μοναδικό  το Σπήλαιο των Λιμνών είναι οι τρείς όροφοι με τις δεκατρείς αλλεπάλληλες
         κλιμακωτές λίμνες.Το καλοκαίρι οι ακτίνες του ήλιου διεισδύουν με δυσκολία από το πυκνό φύλλωμα των αιωνόβιων
         πλατάνων στο Πλανητέρο, καθώς τα ορμητικά νερά του ποταμού στριφογυρίζουν τον παλιό νερόμυλο. </p>
        <div class="bigpic"><img src="./photos/kal.jpg" alt=""></div>
        <div class="picrow">
        <img src="./photos/kalavrita1.jpg" alt="">
        <img src="./photos/kalavrita2.jpg" alt="">
        <img src="./photos/kalavrita3.jpg" alt="">
        <img src="./photos/kalavrita4.jpg" alt="">
      </div>
          <p class="ps">Για όσους πάλι θελήσουν να κάνουν μία θρησκευτική αλλά και ιστορική διαδρομή ή να ζήσουν ένα ξεχωριστό μοναστηριακό
           Πάσχα έξω από τα συνηθισμένα υπό το φως των κεριών και μόνο, δεν πρέπει να παραλείψουν τις μονές του Μεγάλου Σπηλαίου και της Αγίας Λαύρας<br>
          Στη Ζαχλωρού σταθείτε στη μέση της γέφυρας, που ενώνει τις δύο μεριές του φαραγγιού, πάρτε μία βαθιά αναπνοή και αφήστε τον Βουραϊκό να σας πλημμυρίσει…<br>
          Για τους πιο τολμηρούς ένα μπάνιο στη λίμνη είναι μια μοναδική εμπειρία. Οι υπόλοιποι οργανώστε ένα πικ-νικ στην όχθη της και απολάυστε το μαγευτικό τοπίο. </p>
          <a href="#epiloges" style="border-radius:6px;opacity:0.7;display: inline-block;width:43px;height: 25px; background-color: #44cc7c; color: white;"><span style="font-size: 0.9rem; object-fit: contain; margin-left: 5px;"><b>Cart</b></span></a>
    <div class="backtop"> 
    <a href="#top"><span >Back to top </span></a></div>
 <br> <br>
      <hr style="height: 10px;margin-top:15px; margin-bottom:-20px;border: 0;box-shadow: 0 10px 10px -10px #8c8b8b inset;">
        <br>
      <br><br>
      <div style="text-align: center; margin-bottom: 50px; "><img style="border-radius:130px;box-shadow: 0 0 60px #44cc7c;"width="197"src="./photos/logostaff.png" alt=""></div>
      <a id="tri"></a>
<hr style="height: 10px;margin-top:12px;border: 0;margin-bottom:40px;box-shadow: 0 10px 10px -10px #8c8b8b inset;">
      <div  class="picfirst"><p>Tρίπολη</p></div>
     
      <p class="ps">Αν και η πρωτεύουσα της Αρκαδίας δεν αποτελεί τουριστικό προορισμό, ο επισκέπτης που θα έρθει εδώ για 
        μια σύντομη επίσκεψη δεν θα βιαστεί να φύγει. Οι όμορφες, ζωντανές πλατείες της, με κορυφαία την πλατεία Άρεως, τα νεοκλασικά 
        μέγαρα, τα πράσινα άλση, τα γραφικά μαγειρεία γύρω από τη λαϊκή αγορά με τις πυραμίδες από μήλα και τις πλεξούδες με τα σκόρδα
       (αυτά είναι και τα κυριότερα αγροτικά προϊόντα της περιοχής), ο πεζόδρομος της Δεληγιάννη με τα μπαράκια και τη μόνιμη κίνηση 
       είναι μερικές από τις πιο tourist friendly όψεις της Τρίπολης. </p>
        <div class="bigpic"><img src="./photos/tri2.jpg" alt=""></div>
        <div class="picrow">
        <img src="./photos/tripoli1.jpg" alt="">
        <img src="./photos/tripoli2.jpg" alt="">
        <img src="./photos/tripoli3.jpg" alt="">
        <img src="./photos/tripoli4.jpg" alt="">
      </div>
          <p class="ps">Η πλατεία Πετρινού με το Μαλλιαροπούλειο Θέατρο του 1910, η Παλιά Φιλαρμονική και το
             Αρχαιολογικό Μουσείο (έργα και τα δύο του Τσίλερ), το σπίτι του Καρυωτάκη και η πλατεία του Αγίου Βασιλείου 
             (τη Μεγάλη Παρασκευή γίνεται εδώ ο άτυπος διαγωνισμός του καλύτερου Επιταφίου) με την υπερυψωμένη εκκλησία, 
             στο ισόγειο της οποίας στεγάζονται εμπορικά καταστήματα, είναι οι πιο κλασικές στάσεις μιας πρώτης βόλτας 
             στην πόλη, ενώ αν βγείτε από το κέντρο με το αυτοκίνητο, μπορείτε να ανηφορίσετε προς έναν από τους πευκόφυτους 
             λοφίσκους που περιτριγυρίζουν την πόλη και όπου υπάρχουν cafes και ταβέρνες με πανοραμική θέα. <br>Από το φθινόπωρο 
             ως την άνοιξη που έχει λιγότερη ζέστη και μπορείτε να συνδυάσετε την εκδρομή με εξορμήσεις στην ορεινή Αρκαδία.  </p>  
             <a href="#epiloges" style="border-radius:6px;opacity:0.7;display: inline-block;width:43px;height: 25px; background-color: #44cc7c; color: white;"><span style="font-size: 0.9rem; object-fit: contain; margin-left: 5px;"><b>Cart</b></span></a>     
<div class="backtop"> 
    <a href="#top"><span >Back to top </span></a></div>
<hr style=" height: 10px;margin-top:55px;border: 0;margin-bottom:40px;box-shadow: 0 10px 10px -10px #8c8b8b inset;">



      <!---------- end of "ayto na epanalhfthei" --------->
        <br>
     
      
      

      <div style="text-align: center; margin-bottom: 50px; "><img style="border-radius:130px;box-shadow: 0 0 60px #44cc7c;"width="197"src="./photos/logostaff.png" alt=""></div>
      <a id="tri"></a>
<hr style="height: 10px;margin-top:12px;border: 0;margin-bottom:40px;box-shadow: 0 10px 10px -10px #8c8b8b inset;">

      <div  class="picfirst"><p>Tρίπολη</p></div>
     
      <p class="ps">Αν και η πρωτεύουσα της Αρκαδίας δεν αποτελεί τουριστικό προορισμό, ο επισκέπτης που θα έρθει εδώ για 
        μια σύντομη επίσκεψη δεν θα βιαστεί να φύγει. Οι όμορφες, ζωντανές πλατείες της, με κορυφαία την πλατεία Άρεως, τα νεοκλασικά 
        μέγαρα, τα πράσινα άλση, τα γραφικά μαγειρεία γύρω από τη λαϊκή αγορά με τις πυραμίδες από μήλα και τις πλεξούδες με τα σκόρδα
       (αυτά είναι και τα κυριότερα αγροτικά προϊόντα της περιοχής), ο πεζόδρομος της Δεληγιάννη με τα μπαράκια και τη μόνιμη κίνηση 
       είναι μερικές από τις πιο tourist friendly όψεις της Τρίπολης. </p>
        <div class="bigpic"><img src="./photos/tri2.jpg" alt=""></div>
        <div class="picrow">
        <img src="./photos/tripoli1.jpg" alt="">
        <img src="./photos/tripoli2.jpg" alt="">
        <img src="./photos/tripoli3.jpg" alt="">
        <img src="./photos/tripoli4.jpg" alt="">
      </div>
          <p class="ps">Η πλατεία Πετρινού με το Μαλλιαροπούλειο Θέατρο του 1910, η Παλιά Φιλαρμονική και το
             Αρχαιολογικό Μουσείο (έργα και τα δύο του Τσίλερ), το σπίτι του Καρυωτάκη και η πλατεία του Αγίου Βασιλείου 
             (τη Μεγάλη Παρασκευή γίνεται εδώ ο άτυπος διαγωνισμός του καλύτερου Επιταφίου) με την υπερυψωμένη εκκλησία, 
             στο ισόγειο της οποίας στεγάζονται εμπορικά καταστήματα, είναι οι πιο κλασικές στάσεις μιας πρώτης βόλτας 
             στην πόλη, ενώ αν βγείτε από το κέντρο με το αυτοκίνητο, μπορείτε να ανηφορίσετε προς έναν από τους πευκόφυτους 
             λοφίσκους που περιτριγυρίζουν την πόλη και όπου υπάρχουν cafes και ταβέρνες με πανοραμική θέα. <br>Από το φθινόπωρο 
             ως την άνοιξη που έχει λιγότερη ζέστη και μπορείτε να συνδυάσετε την εκδρομή με εξορμήσεις στην ορεινή Αρκαδία.  </p>   
<a href="#epiloges" style="border-radius:6px;opacity:0.7;display: inline-block;width:43px;height: 25px; background-color: #44cc7c; color: white;"><span style="font-size: 0.9rem; object-fit: contain; margin-left: 5px;"><b>Cart</b></span></a>

<div class="backtop"> 
    <a href="#top"><span >Back to top </span></a></div>
<hr style=" height: 10px;margin-top:55px;border: 0;margin-bottom:40px;box-shadow: 0 10px 10px -10px #8c8b8b inset;">
      <div style="text-align: center; margin-bottom: 50px; "><img style="border-radius:130px;box-shadow: 0 0 60px #44cc7c;"width="197"src="./photos/logostaff.png" alt=""></div>

 <a id="epiloges"></a>
<hr style=" height: 10px;margin-top:55px;border: 0;margin-bottom:40px;box-shadow: 0 10px 10px -10px #8c8b8b inset;">


      <!---------- end of "ayto na epanalhfthei" --------->
   <br>
      <br><br>
      <br>
      <br>


      <div style="padding:35px; border-radius:20px; max-width:380px; min-width:300px;height:370px;margin:-79px auto 70px auto; box-shadow: 0 0 50px #44cc7c;">
    <p style="text-align:center;letter-spacing: 1px; font-size: 1.05rem; font-weight: bold;"><u style="text-decoration: underline; text-decoration-color: #44cc7c;  ">Επιλέξτε Προορισμό!</u></p>
    <form  id="eventform" >
      <?php
      
      // Εμφάνιση αποτελεσμάτων event////////////////////////////////////////////////////////////////////////////////////
	  
	  for ($i=0;$i<$count;$i++){
        echo "<input type='checkbox' class='inputClass' value=$event_id[$i] name='selection[]'  />" . " " . $event_name[$i] ." " .  $event_desc[$i] ." " . $event_cost[$i] ." EUR" ." " ."<br>";
      }
      
        ?>
      <br>
      <button type="button" id="eventbutton"style="width:200px;border-color:#44cc7c; border-radius: 0; background-color:#44cc7c; margin-right:4px;"class="btn btn-primary"><b> Το καλάθι μου</b></button><img style="width:30%;display:inline-block; margin-top:-100px;margin-left: 195px;" src="./photos/scart.png" alt="">
      </form>
      </div>
<hr style="height: 10px;margin-top:70px;border: 0;margin-bottom:99px;box-shadow: 0 10px 10px -10px #8c8b8b inset;">
  <!-- --> 
    <form id="form1"  method="post" action="addrating.php"style="max-width: 400px;min-width: 330px; height: 530px;  background: rgba(0, 0, 0, 0.15); margin-left: auto;margin-right: auto; border: 2px solid #44cc7c; border-radius: 15px; padding:37px; box-shadow: 0 0 25px black;">
      <div style="">
<p style="text-align: center; font-size: 1.1rem; margin-bottom: 25px; font-weight: bold;">H γνώμη σας μετράει!<br>Πείτε μας πως περάσατε στην εκδρομή σας! </p>

            <br>

            <div class="form-group">
            <?php
            // Εμφάνιση αποτελεσμάτων event σε drop down list, select name gets data from option value 
            echo "<label for='inputevent'>Επιλέξτε ονομα εκδρομής </label>";
            echo "<br>";

             echo "<select name='inputeventid'>";
            for ($i=0;$i<$count;$i++){
              echo "<option value=$event_id[$i]>" . " " . $event_name[$i] . "<br>";
            }
            echo "</select>";
            ?>
            <br>
            <br>

              <label for="inputmark">Εισάγετε βαθμολογία απο 1 έως 5</label>
              <input type="number" style="width: 95%" class="form-control" id="inputmark" name="inputmark" placeholder="Βαθμολογία εκδρομής" min="1" max="5"><br>

              <label for="inputcomm">Εισάγετε Σχόλιο</label>
              <input type="text" style="max-width: 330px;min-width: 200px; margin-bottom: 25px; border-color:#44cc7c;" class="form-control" id="inputcomm" name="inputcomm" placeholder="Σχόλιο εκδρομής">

            </div>
            <button style="width:200px;border-color:#44cc7c; border-radius: 5px; background-color:#44cc7c; margin-right:4px; type="submit" class="btn btn-primary"><b>Προσθήκη</b></button>
            <button type="reset" class="btn btn-secondary" style="margin:8px 0;"><b>Καθαρισμός</b></button>
            </div>
          </form>

         
          <br>
<br>
<br>
<form id="form1" >
            <div class="form-group">
              <label for="inputevent" style=" letter-spacing:1px; font-weight:bold; text-decoration: underline; text-decoration-color: #44cc7c;">Δείτε την αξιολόγηση των εκδρομών μας</label>

              <input type="text" class="form-control" id="inputevent02" name="inputevent" placeholder="Όνομα εκδρομής">
            </div>
            <button type="button" onclick="loadXML2()"style="width:200px;border-color:#44cc7c; border-radius: 5px; background-color:#44cc7c; margin-right:4px;"class="btn btn-primary"><b>Αναζήτηση</b></button>
            <button type="reset" class="btn btn-secondary"><b>Καθαρισμός</b></button>
          </form>
          <p id="demo2"></p>

</div>


    <script>
// get data from document.cookie created at cart.php 
// with try catch in case of empty cart wont need to execute below part of code

  

//if(typeof mystorage === "undefined")
// smaller or equal than 2 because eithet it will be empty or will contain brackets from array initialization
if (getCookie("mystorage").length <= 2 ){
    mystorage = [];
    //console.log(typeof mystorage);
    // ορίζεται άδειο cookie
    setCookie("mystorage", JSON.stringify(mystorage), 1);
    console.log(JSON.parse(getCookie("mystorage")));
  }else{
    
    console.log(JSON.parse(getCookie("mystorage")));
    mystorage = JSON.parse(getCookie("mystorage"));

    let elements= document.getElementById("eventform");

//place check on events when user navigates away from main view  
  for (let i = 0; i < elements.length; i++) {
        for (let j = 0; j < mystorage.length; j++) {
          
          if (mystorage[j][0] === elements[i].value) {
            
            elements[i].checked=true;
            
            //console.log(mystorage);
            
            }
        }
  }   
}


/////////////////////////////////////////////////////////////////////////////

//mystorage[j]=([j,1]);
//event delegate
document.getElementById("eventform").addEventListener('click', event => {
      if (event.target.className  === 'inputClass') { 
        
        if (event.target.checked){
          

          mystorage = JSON.parse(getCookie("mystorage"));
          mystorage.push([event.target.value,1]);
          setCookie("mystorage", JSON.stringify(mystorage), 1);
          console.log(JSON.parse(getCookie("mystorage")));
          

        }else{
          
          for(let i=0; i<mystorage.length; i++) {
            
            if ( mystorage[i][0] === event.target.value) {
              //remove specific element based on its value 
              mystorage = JSON.parse(getCookie("mystorage"));
              mystorage.splice(i, 1);
              console.log("uncheck");
              console.log(mystorage);
              setCookie("mystorage", JSON.stringify(mystorage), 1);
              
              
          }
        }
      }
     }
     
    });


////////////////////////////////////////////
document.getElementById("eventbutton").addEventListener("click", function(){
      
      window.location.href = "cart.php";
    });
///////////////////////////////////////////////////////////////
function loadXML() {
    var xhttp = new XMLHttpRequest();
    var data01 = document.getElementById("inputevent01").value;
    var vars = "inputevent01="+data01;
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
          // Typical action to be performed when the document is ready:
          document.getElementById("demo").innerHTML = xhttp.responseText;
        }
    };
    xhttp.open("POST", "eventbyname.php", true);
    xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhttp.send(vars);
}

function loadXML2() {
    var xhttp = new XMLHttpRequest();
    var data02 = document.getElementById("inputevent02").value;
    var vars = "inputevent02="+data02;
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
          // Typical action to be performed when the document is ready:
          document.getElementById("demo2").innerHTML = xhttp.responseText;
        }
    };
    xhttp.open("POST", "ratingbyname.php", true);
    xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhttp.send(vars);
}


////////////////////////////////////////////////
function setCookie(cname, cvalue, exdays) {
      var d = new Date();
      d.setTime(d.getTime() + (exdays*24*60*60*1000));
      var expires = "expires="+ d.toUTCString();
      document.cookie = cname + "=" + cvalue + ";" + expires  ;
     
    }

    function getCookie(cname) {
      var name = cname + "=";
      var decodedCookie = decodeURIComponent(document.cookie);
      var ca = decodedCookie.split(';');
      for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }
    
    </script> 
    
    <div style="margin:20px 0 40px 0;"> 
    <a  style="margin-left: 45%; margin-top: 10px; color:#44cc7c;" href="#top">Back to top <i class="fas fa-angle-double-up"></i></a></div> 
    
    <script>
    document.getElementById("messagebtn").addEventListener("click", function(){
  
    window.location.href = "usermsg.php";
    });
    </script>
    <footer style="background-color: #1a1b1d; height: 110px; width: 100%;">
      <p style="text-align: center; color:white; padding-top: 60px;">® All rights Reserved by Kyriakos</p>
    </footer>
    </body>
</html>    
          