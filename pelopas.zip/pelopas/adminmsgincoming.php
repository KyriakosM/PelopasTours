<!DOCTYPE html>
<html>
  <?php

  //session_start();
  require_once 'connection.php';


// εισερχόμενα μηνυματα 
if ($stmt = $dbconn->prepare('select inbound_id,user_id,message,date from inbound')){
  
  $stmt->execute(); 
  $stmt->store_result();   

  if ($stmt->num_rows > 0) {
    // bind results
    $count2=$stmt->num_rows;
    $stmt->bind_result($in_id,$u_id,$msg,$when);
    //statement fetch results
    while ($stmt->fetch()){
      // use column variables from binding
      $inbound_id[]=$in_id;
      $user_id[]=$u_id;
      $message[]=$msg;
      $date[]=$when;
    }
  }else{
    exit ("Σεν υπάρχουν εισερχόμενα μηνύματα");
  }
}

$stmt->close();

?>

<p><h3>Eισερχόμενα μηνυματα</h3></p>
  <table id="mytable2" >
  <thead>
  <tr><th>Κωδικός<br>εισερχομένου</th><th>Κωδικός<br>χρήστη</th><th>Μήνυμα</th><th>Ημερομηνία</th></tr>
  </thead>
  <?php
  // Εμφάνιση αποτελεσμάτων 
  for ($i=0;$i<$count2;$i++){
    echo "<tr>" ."<td>".  $inbound_id[$i] ."</td>" 
    ."<td>".  $user_id[$i] ."</td>" 
    ."<td>". $message[$i] ."</td>" 
    ."<td>". $date[$i] ."</td></tr>";
  }
  ?>
  </table>
  

<script>


</script>


</html>