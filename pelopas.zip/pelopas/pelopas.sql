-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jan 13, 2021 at 09:37 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pelopas`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_order`
--

CREATE TABLE `customer_order` (
  `customer_order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_order_date` datetime DEFAULT NULL,
  `order_total_cost` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_order`
--

INSERT INTO `customer_order` (`customer_order_id`, `user_id`, `customer_order_date`, `order_total_cost`) VALUES
(14, 10, '2020-12-23 20:11:16', 45),
(15, 22, '2020-12-23 20:13:37', 85),
(16, 25, '2020-12-23 20:59:24', 115),
(17, 10, '2020-12-23 21:12:15', 100),
(18, 22, '2020-12-23 21:13:28', 80),
(23, 10, '2021-01-07 20:51:07', 115),
(24, 25, '2021-01-13 21:33:04', 125);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(45) NOT NULL,
  `event_desc` varchar(200) DEFAULT NULL,
  `event_cost` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `event_name`, `event_desc`, `event_cost`) VALUES
(6, 'ΤΡΙΠΟΛΗ', 'Σ/Κ - 20/3/2021', 100),
(7, 'ΚΑΛΑΜΑΤΑ', 'ΑΓΡΟ - 14/3/2021', 25),
(8, 'ΚΑΛΑΒΡΥΤΑ', 'ΣΚΙ  7/3/2021', 15),
(9, 'ΒΥΤΙΝΑ', 'ME ΓΕΥΜΑ 28/3/2021', 30),
(10, 'ΒΥΤΙΝΑ ΜΟΝΟΠΑΤΙ', '28/3/2/2021', 10);

-- --------------------------------------------------------

--
-- Table structure for table `inbound`
--

CREATE TABLE `inbound` (
  `inbound_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_email` varchar(45) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inbound`
--

INSERT INTO `inbound` (`inbound_id`, `user_id`, `user_email`, `message`, `date`) VALUES
(2, 10, NULL, 'Καλησπέρα σας. θα ήθελα το τηλέφωνο του ξενοδοχείου', '2020-12-24 13:25:50'),
(7, 25, NULL, 'Ώρα και σημείο αναχώρησης?', '2021-01-07 20:54:51');

-- --------------------------------------------------------

--
-- Table structure for table `order_line`
--

CREATE TABLE `order_line` (
  `customer_order_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `event_quant` int(11) NOT NULL,
  `event_cost` float DEFAULT NULL,
  `total_cost` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_line`
--

INSERT INTO `order_line` (`customer_order_id`, `event_id`, `event_quant`, `event_cost`, `total_cost`) VALUES
(14, 6, 1, 20, 20),
(14, 7, 1, 25, 25),
(15, 8, 1, 15, 15),
(15, 9, 2, 30, 60),
(15, 10, 1, 10, 10),
(16, 7, 1, 25, 25),
(16, 9, 3, 30, 90),
(17, 6, 4, 20, 80),
(17, 10, 2, 10, 20),
(18, 6, 3, 20, 60),
(18, 10, 2, 10, 20),
(23, 6, 2, 20, 40),
(23, 7, 3, 25, 75),
(24, 6, 1, 100, 100),
(24, 7, 1, 25, 25);

-- --------------------------------------------------------

--
-- Table structure for table `outbound`
--

CREATE TABLE `outbound` (
  `outbound_id` int(11) NOT NULL,
  `inbound_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_email` varchar(45) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `outbound`
--

INSERT INTO `outbound` (`outbound_id`, `inbound_id`, `user_id`, `user_email`, `message`, `date`, `staff_id`) VALUES
(3, 2, 10, NULL, 'Εκπρόσωπός μας θα επικοινωνήσει μαζί σας τηλεφωνικά.', '2020-12-24 14:30:00', NULL),
(8, 7, 25, NULL, 'Στις 07:00, Πλατεία Συντάγματος.', '2021-01-07 20:57:13', 15);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `rating_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `rate` int(1) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`rating_id`, `user_id`, `event_id`, `rate`, `description`, `date`) VALUES
(8, 10, 6, 5, 'ΗΤΑΝ ΟΛΑ ΕΞΑΙΡΕΤΙΚΑ', '2020-12-13 21:58:41'),
(9, 22, 6, 5, 'ΠΕΡΑΣΑΜΕ ΦΑΝΤΑΣΤΙΚΑ', '2020-12-14 23:44:44'),
(10, 10, 8, 5, 'ΥΠΕΡΟΧΗ ΕΚΔΡΟΜΗ', '2020-12-18 12:39:43'),
(11, 22, 8, 5, 'ΦΟΒΕΡΗ ΕΜΠΕΙΡΙΑ', '2020-12-18 12:40:09');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_type_id` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(260) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `surname` varchar(45) DEFAULT NULL,
  `telephone` bigint(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_type_id`, `username`, `password`, `name`, `surname`, `telephone`, `address`, `email`) VALUES
(10, 5, 'user1', '$2y$10$elWzO7hfm4Fh5mVtk.ztUuBPk3HivPHm2S5EtsvclTcMpRhWjkEte', 'ΜΑΡΙΑ', 'ΛΕΓΑΚΗ', 6977334455, 'Λεωφ. Αγ. Δημητρίου 405 Αθήνα 17343', 'm.legaki@gmail.com'),
(15, 6, 'admin1', '$2y$10$elWzO7hfm4Fh5mVtk.ztUuBPk3HivPHm2S5EtsvclTcMpRhWjkEte', 'ΜΙΧΑΛΗΣ', 'ΣΤΡΑΤΑΚΗΣ', 6988213141, 'Σόλωνος 117 Ηλιούπολη', 'mstratak@yahoo.com'),
(25, 5, 'user2', '$2y$10$elWzO7hfm4Fh5mVtk.ztUuBPk3HivPHm2S5EtsvclTcMpRhWjkEte', 'ΑΓΑΠΗ', 'ΣΤΕΦΑΝΙΔΗ', 6955454601, 'Αντιγόνης 7 Παλαιό Φάληρο', 'stefanidiag@gmail.com'),
(22, 5, 'user3', '$2y$10$elWzO7hfm4Fh5mVtk.ztUuBPk3HivPHm2S5EtsvclTcMpRhWjkEte', 'ΣΤΕΛΛΑ', 'ΕΡΜΙΔΗ', 6992000222, 'Λεωφ. 62 Μαρτύρων 22 Ηράκελιο', 'hermides@gmail.com'),
(23, 6, 'admin2', '$2y$10$elWzO7hfm4Fh5mVtk.ztUuBPk3HivPHm2S5EtsvclTcMpRhWjkEte', 'EΛΕΝΗ', 'ΣΑΡΑΝΤΟΠΟΥΛΟΥ', 6998002277, 'Πλαστήρα 33 Χαϊδάρι', 'sarantopoulou@hotm.mail.com'),
(24, 6, 'admin3', '$2y$10$elWzO7hfm4Fh5mVtk.ztUuBPk3HivPHm2S5EtsvclTcMpRhWjkEte', 'ΠΗΝΕΛΟΠΗ', 'ΜΙΧΑΗΛΙΔΗ', 6977526098, 'Καλιρόης 19 Ελευσίνα', 'mix.pin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

CREATE TABLE `user_type` (
  `user_type_id` int(11) NOT NULL,
  `user_type_name` varchar(45) CHARACTER SET armscii8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`user_type_id`, `user_type_name`) VALUES
(6, 'staff'),
(5, 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD PRIMARY KEY (`customer_order_id`),
  ADD KEY `fk3_idx` (`user_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `inbound`
--
ALTER TABLE `inbound`
  ADD PRIMARY KEY (`inbound_id`);

--
-- Indexes for table `order_line`
--
ALTER TABLE `order_line`
  ADD PRIMARY KEY (`customer_order_id`,`event_id`),
  ADD KEY `FKevent_id_idx` (`event_id`);

--
-- Indexes for table `outbound`
--
ALTER TABLE `outbound`
  ADD PRIMARY KEY (`outbound_id`),
  ADD KEY `FKinbound_reference_idx` (`inbound_id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`rating_id`),
  ADD KEY `FKevent_id_idx` (`event_id`),
  ADD KEY `fk2_idx` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username_UNIQUE` (`username`),
  ADD KEY `fk1_idx` (`user_type_id`);

--
-- Indexes for table `user_type`
--
ALTER TABLE `user_type`
  ADD PRIMARY KEY (`user_type_id`),
  ADD UNIQUE KEY `user_type_name_UNIQUE` (`user_type_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_order`
--
ALTER TABLE `customer_order`
  MODIFY `customer_order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `inbound`
--
ALTER TABLE `inbound`
  MODIFY `inbound_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `outbound`
--
ALTER TABLE `outbound`
  MODIFY `outbound_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `rating_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user_type`
--
ALTER TABLE `user_type`
  MODIFY `user_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD CONSTRAINT `fk3` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `order_line`
--
ALTER TABLE `order_line`
  ADD CONSTRAINT `FKcustomer_order` FOREIGN KEY (`customer_order_id`) REFERENCES `customer_order` (`customer_order_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FKevent_id` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `outbound`
--
ALTER TABLE `outbound`
  ADD CONSTRAINT `FKoutbound_reference` FOREIGN KEY (`inbound_id`) REFERENCES `inbound` (`inbound_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `rating`
--
ALTER TABLE `rating`
  ADD CONSTRAINT `FKrating_event_id` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk1` FOREIGN KEY (`user_type_id`) REFERENCES `user_type` (`user_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
