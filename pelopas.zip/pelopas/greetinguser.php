<!DOCTYPE html>
<html>
      <head>
        <title>PELOPAS TRAVEL</title>
        <link rel="stylesheet" href="style.css">
        
        <meta charset="utf-8">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">  
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet"> 

        <style>
          .s{
  box-shadow: 0 0 19px black;
  width: 100%;
  height: 500px;
  border-bottom: 4px solid #44cc7c;
  background-image: url(./photos/p.jpg);
  background-repeat: no-repeat;
  background-position: center;
  background-attachment: fixed;
          }
       
          .welcome{
            color: #F5F5F5;
            text-shadow: 0 0 5px black;
            animation: fr 2.3s 1;
            margin:-350px auto 350px auto;
            animation-fill-mode: forwards;
            font-size: 5rem;
            font-family: 'Dancing Script', cursive;
          }
@keyframes fr{
  0%{
    transform: translateX(-600px);
    opacity: 0;
  }
  100%{
    transform: translateX(40px);
    opacity: 1;
  }
}

}
        </style>
    </head>
    <body>
      <div class="s" style="background-color:black; width: 100%; height: 65vh; ">
        
            </div>
            
      <!---------- Main Navigation Bar ----------->
      
   <nav class="navbar navbar-expand-md navbar-dark navbar-custom">
  <a class="navbar-brand notthis" href="index.php"><img id="mainlogo" src="./photos/logo.png" alt="Logo" ></a>

   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation" >
    <span class="navbar-toggler-icon ic"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav" >
      <li class="nav-item active">
        <a class="nav-link navbar-text notthis" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link navbar-text notthis" href="pricing.html" style="color:white;">Shop</a>
      </li>
      <li class="nav-item">
        <a class="nav-link navbar-text notthis" href="pricing.html"style="color:white;">Trips</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle navbar-text notthis"style="color:white;" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Sign In
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item notthis" href="#" id="signin">Sign In</a>
          <a class="dropdown-item notthis" href="#" id="goToNewAcc">Sign Up</a>
        </div>
        <li class="nav-item custom-text"style="margin-left: 211px;">
          <a class="nav-link nav-about navbar-text notthis" aria-current="page" href="systeminfo.html"style="color:white;">About</a>
        </li>
      </li>
    </ul>
  </div>
</nav>

  





      <?php
    //session_start();
    require_once 'connection.php';
?>
      <!-- επικεφαλίδα -->
<div class="container">
      <br>
      <div class="welcome">
      <?php echo '<p> Καλώς ήρθατε  ' . $_SESSION['name'] . ' !</p>'; ?>
      </div>
         
    </div>

    <script>
    document.getElementById("mybtn").addEventListener("click", function(){
        window.location.href = "personaldata.php";
    });

    document.getElementById("history").addEventListener("click", function(){
     window.location.href = "history.php";
    });

    document.getElementById("tomenu").addEventListener("click", function(){
    window.location.href = "main.php";
    });
	
    </script>
     <!--------- Bootstrap JS --------->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>

    </html>