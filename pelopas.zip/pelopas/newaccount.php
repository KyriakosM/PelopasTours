<!DOCTYPE html>
<html>
    <head>
       <title>PELOPAS TRAVEL</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <script src="https://kit.fontawesome.com/yourcode.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@500&display=swap" rel="stylesheet"> 
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@1,700&display=swap" rel="stylesheet"> 
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet"> 
    </head>
    <style>
      body{
      background-image:url("./photos/main.jpg");
      background-size: cover;

      }
    </style>
    <body>
<nav class="navbar navbar-expand-md navbar-dark navbar-custom">
  <a class="navbar-brand notthis" href="index.php"><img id="mainlogo" src="./photos/logo.png" alt="Logo" ></a>

   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation" >
    <span class="navbar-toggler-icon ic"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav" style="background:black;">
      <li class="nav-item active">
        <a class="nav-link navbar-text " href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link navbar-text " href="pricing.html" style="color:white;">Shop</a>
      </li>
      <li class="nav-item">
        <a class="nav-link navbar-text " href="pricing.html"style="color:white;">Trips</a>
      </li>
        
      </li>
    </ul>
  </div>
</nav>

<p style="text-align:center;margin:50px 0 0 0;text-shadow: 0 0 3px #44cc7c; color:white; letter-spacing: 1px; font-size: 1.2rem;">Παρακαλούμε <u>εγγραφείτε</u> για να αποκτήσετε<br>πρόσβαση σε όλο το περιεχόμενο της σελίδας!</p>
<p id="auxiliaryText"></p>

		<!-- create padding -->
<div class="container">
<div class="newacc2">
    <h4 style="margin-top: 22px; margin-left: -7px; font-family: Ubuntu;">Καταχωρείστε τα στοιχεία σας</h4>
		<form id="form2" method="post" action="addtodb.php">
            <div class="form-group">
              <label style=" text-shadow: 1px 1px black;margin-top:30px;font-size:1.1rem; font-weight:bold; color:white;"for="inputEmail">Όνομα χρήστη:</label>
              <input type="text" style="width:315px" class="form-control" maxlength="45" id="inputUser" name="inputUser" placeholder="username">
            </div>
            <div class="form-group">
              <label style="margin-top:8px; text-shadow: 1px 1px black;  font-size:1.14rem; font-weight:bold; color:white;" for="inputPassword">Κωδικός:</label>
              <input type="password"style="width:315px" class="form-control" maxlength="260" id="inputPassword" name="inputPassword" placeholder="password">
            </div>
			<div class="form-group">
              <label style="margin-top:8px; text-shadow: 1px 1px black;  font-size:1.14rem; font-weight:bold; color:white;" for="inputPassconfirm">Επιβεβαίωση κωδικού:</label>
              <input type="password"style="width:315px" class="form-control" maxlength="260" id="inputPassconfirm" name="inputPassconfirm" placeholder=" Confirm password">
            </div>
			<div class="form-group">
              <label style="margin-top:8px; text-shadow: 1px 1px black;  font-size:1.14rem; font-weight:bold; color:white;" for="inputSurname">Επίθετο:</label>
              <input type="text"style="width:315px; text-transform: uppercase;" class="form-control" maxlength="45" id="inputSurname" name="inputSurname" placeholder="Surname">
            </div>
			<div class="form-group">
              <label style="margin-top:8px; text-shadow: 1px 1px black;  font-size:1.14rem; font-weight:bold; color:white;" for="inputΝame">Όνομα:</label>
              <input type="text"style="width:315px; text-transform: uppercase;" class="form-control" maxlength="45"  id="inputName" name="inputName" placeholder="Name">
            </div>		
			<div class="form-group">
              <label style="margin-top:8px; text-shadow: 1px 1px black;  font-size:1.14rem; font-weight:bold; color:white;" for="inputAddress">Διεύθυνση:</label>
              <input type="text"style="width:315px" class="form-control" maxlength="50" id="inputAddress" name="inputAddress" placeholder="Address">
            </div>
			<div class="form-group">
              <label style="margin-top:8px; text-shadow: 1px 1px black;  font-size:1.14rem; font-weight:bold; color:white;" for="inputEmail">E-mail:</label>
              <input type="text" style="width:315px" class="form-control" maxlength="45" id="inputEmail" name="inputEmail" placeholder="E-mail">
            </div>			
			<div class="form-group">
              <label style="margin-top:8px; text-shadow: 1px 1px black;  font-size:1.14rem; font-weight:bold; color:white;" for="inputTelephone">Τηλέφωνο:</label>
              <input type="number"style="width:315px" class="form-control" maxlength="20" id="inputTelephone" name="inputTelephone" placeholder="Telephone">
            </div>			
            <button type="submit" class="koubi" style=" margin-top:12px;  margin-right:16px;"class="btn btn-primary">Υποβολη</button>
            <button type="reset" class="koubi" style=" margin-top:12px;"class="btn btn-secondary">Καθαρισμος</button>
                        <br><br><a href="index.php" class="koubi a"style="margin-top:25px;">Επιστροφη</a>
<br>
          </form>
         <br>
        </div>
		</div>
          
    <footer style="background-color: #1a1b1d; height: 110px; width: 100%;">
      <p style="text-align: center; color:white; padding-top: 60px;">® All rights Reserved by Kyriakos</p>
    </footer>
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
</html>

