<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

th {text-align:center;
}

</style>

</head>
<body>
  <?php

        //session_start();
      require_once 'greetinguser.php';
  

        if ($stmt = $dbconn->prepare('SELECT customer_order.customer_order_id, event_name, event_quant, customer_order_date,total_cost
        FROM customer_order
        inner join order_line
        on customer_order.customer_order_id = order_line.customer_order_id
        inner join event
        on order_line.event_id = event.event_id 
        inner join user
        on customer_order.user_id = user.user_id 
        where user.user_id = (?)')) {
          //s = string i= int d=double
        $stmt->bind_param('s', $_SESSION['id']);
        $stmt->execute(); 
        $stmt->store_result(); 
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $count=$stmt->num_rows;
          $stmt->bind_result($cο_corderid,$e_name,$e_quant,$co_date,$t_cost);
          //statement fetch results
          while ($stmt->fetch()){
            // use column variables from binding
            $custorder_orderid[]=$cο_corderid;
            $event_name[]=$e_name;
            $event_quant[]=$e_quant;
            $custorder_date[]=$co_date;
            $orderline_totalcost[]=$t_cost;
          }
        }else{
          
          exit('<p style="font-size:2rem; text-shadow: 0 0 15px red; margin-top:29px; margin-left:3%;">"Δεν βρέθηκαν εγγραφές"</p>');
        }

        /////query2 agores/////

        if ($stmt = $dbconn->prepare('SELECT customer_order_id, customer_order_date, order_total_cost
        FROM customer_order
        inner join user
        on customer_order.user_id = user.user_id 
        where user.user_id = (?)')) {
          //s = string i= int d=double
        $stmt->bind_param('s', $_SESSION['id']);
        $stmt->execute(); 
        $stmt->store_result(); 
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $count2=$stmt->num_rows;
          $stmt->bind_result($myorderid,$mydate,$mytotalcost);
          
          //statement fetch results
          while ($stmt->fetch()){
            
            // use column variables from binding
            $cust_orderid[]= $myorderid;
            $cust_date[]= $mydate;
            $cust_totalcost[]= $mytotalcost;
          }
        }else{
          
          exit('<p style="font-size:2rem; text-shadow: 0 0 15px red; margin-top:29px; margin-left:3%;">"Δεν βρέθηκαν εγγραφές"</p>');
        }


        
        $stmt->close();
      ?>

	<button type="button" id="messagebtn" style=" border-color: #44cc7c; width:200px; background-color:#44cc7c; margin-right:4px;margin-left:78%;"class="btn btn-primary"><b>ΕΠΙΣΤΡΟΦΗ</b></button>


    <script>
    document.getElementById("messagebtn").addEventListener("click", function(){
  
    window.location.href = "main.php";
    });
    </script>   

<!-- --> 

<p style="text-align: center; padding-top: 65px; font-weight: bold;">ΑΓΟΡΕΣ</p>
<div style="padding-left: 36%; margin-bottom: 85px;">

      <?php
 
      echo "<table><thead>";
      echo "<tr><th style= text-align:center;>Κωδικός<br>Παραγγελίας</th><th style= text-align:center;> Ημερομηνία</th><th style= text-align:center;>Συνολικό<br>κόστος</th></tr>";
      echo "</thead>";
      // Εμφάνιση αγορών//
      for ($i=0;$i<$count2;$i++){
        echo "<tr>". "<td>" . $cust_orderid[$i] ."</td>" ."<td>". $cust_date[$i]."</td>" ."<td>". $cust_totalcost[$i] . "</td>" ."</tr>";
      }
      echo "</table>" ;
        ?>	
</div>

<p style="text-align: center; padding-top: 65px; font-weight: bold;">ΑΓΟΡΕΣ ΑΝΑΛΥΤΙΚΑ</p>
<div style="padding-left: 36%; margin-bottom: 85px;">

      <?php
 
      echo "<table><thead>";
      echo "<tr><th style= text-align:center;>Κωδικός<br>Παραγγελίας</th><th style= text-align:center;> Προορισμός</th><th style= text-align:center;> Αριθμός<br> Εισιτηρίων</th><th style= text-align:center;> Ημερομηνία</th><th style= text-align:center;>Κόστος<br>ανά προορισμό</th></tr>";
      echo "</thead>";
      // Εμφάνιση αγορών//
      for ($i=0;$i<$count;$i++){
        echo "<tr>". "<td>" . $custorder_orderid[$i] ."</td>" ."<td>".  $event_name[$i] ."</td>". "<td>" . $event_quant[$i] ."</td>". 
        "<td>" . $custorder_date[$i]."</td>" ."<td>".$orderline_totalcost[$i]  . "</td>" ."</tr>";
      }
      echo "</table>" ;
        ?>	
</div>


<footer style="background-color: #1a1b1d; height: 110px; width: 100%;">
      <p style="text-align: center; color:white; padding-top: 60px;">® All rights Reserved by Andreas,Mihalis,Kyriakos</p>
    </footer>
</body>
</html>
      

      