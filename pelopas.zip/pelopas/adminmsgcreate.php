<!DOCTYPE html>
<html>
  <?php

  //session_start();
  require_once 'connection.php';

  if ( empty($_POST['messagetxt']) || empty($_POST['user_id']) || empty($_POST['inbound_id']) ) {
    exit('Παρακαλούμε συμπληρώστε όλα τα πεδία');
  }

  $datetime = date('Y-m-d H:i:s');
// δημιουργία νέου μηνύματος
  if ($stmt = $dbconn->prepare('insert into outbound(inbound_id,user_id,message,date,staff_id) values (?,?,?,?,?);')){
    $stmt->bind_param('ssssi', $_POST['inbound_id'], $_POST['user_id'],$_POST['messagetxt'],$datetime,$_SESSION['id']);
    $stmt->execute(); 
      
    exit ("Το μήνυμα απεστάλη");
      
  }


$stmt->close();

?>


</html>