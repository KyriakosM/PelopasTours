<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
  th{
    padding: 8px;
  }
</style></head>
<body >
      
      
      <?php
      //session_start();
      require_once 'greetinguser.php';

      $aux = json_decode($_COOKIE["mystorage"],true);

      for ($x = 0; $x < count($aux); $x++) {
          $arr[$x] = $aux[$x][0] ;
      }
      /*
      foreach($arr as $var){
        echo $var ;
    }
    */

      if (empty($arr)){
          exit ('<h3 style="text-align:center; margin-top: 2%;font-size:2.3rem; color:white; text-shadow: 0 0 25px red;"><b>- Δεν έχετε επιλέξει κάποιον προορισμό! -</b></h3><br><p style="text-align:center;">Επιλέξτε την Κεντρική Σελίδα για να συνεχίσετε</p>');
      }
        //event query receive data from post array 
        // χρησιμοποιήσαμε ήδη το  
        if ($stmt = $dbconn->prepare('SELECT * FROM event WHERE event_id IN (' . implode(',', $arr) . ')')) {
          $stmt->execute(); 
          $stmt->store_result();
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $count=$stmt->num_rows;
          $stmt->bind_result($e_id,$e_name,$e_desc,$e_cost);
          //statement fetch results
          while ($stmt->fetch()){
            // use column variables from binding
            $event_id[]=$e_id;
            $event_name[]=$e_name;
            $event_desc[]=$e_desc;
            $event_cost[]=$e_cost;
          }
        }

        //foreach($arr as $val){
          //echo $val;
        //}
        
        $stmt->close();

        // initialize quantity to be selected per event
        $myvalues = array(1,2,3,4,5);

      ?>

<div style="text-align: center; margin-top: 90px; margin-bottom: 160px; width: 500px; margin-left:auto;margin-right:auto;height: 250px;background-color: rgba(0,0,0,0.1); ">
    <p style="letter-spacing:1px; font-size: 1.2rem; font-weight: bold; background-color: rgba(0,0,0,0.1);">Οι αγορές μου</p>
    <form id="form1" >
      <table id="mytable"border="1" style="margin-left: auto;margin-right: auto;"><thead>
      <tr><th>#</th><th>Προορισμός</th><th>Ποσό</th><th>Νόμισμα</th><th>Ατομα</th><th>Tιμή</th><th></th></tr>
      </thead>
      <?php

      // Εμφάνιση αποτελεσμάτων event
      // διαχωρισμός echo και χρηση loop για το option array
      // εισαγωγή επιπλέον στοιχείου data εντός html tag
      for ($i=0;$i<$count;$i++){
        echo "<tr id=$event_id[$i] >". "<td >".  $event_id[$i] ."</td>" ."<td>".  $event_name[$i] ."</td>" ."<td>". $event_cost[$i] ."</td>" ."<td>". " EUR" .
        "</td>" ."<td>". "<select  id='data' data-event=$event_id[$i] data-cost=$event_cost[$i]  >"; 
        //count(myvalues)
        for ($j=0;$j< count($myvalues);$j++){
        echo "<option value=$myvalues[$j] >" . " " . $myvalues[$j] ; 
        }
        // εισαγωγή στοιχείου μερικού συνόλου
        echo "</select>" ."</td>" ."<td class='injected'>"." ... "."</td>";
        echo "<td style= background-color:#FF0000>"."<a role='button' id='removal' data-value=$event_id[$i] data-name=$event_name[$i]>" . "Αφαίρεση" . "</a>" ."</td>" . "</tr>" ;
        
      }
      
        ?>
        </table>
      <br>
      <button type="button" id="gotoreceipt" style="margin-bottom: 8px; border-radius: 5px; background-color: #44cc7c; color: white; font-weight: bold; border-color: #44cc7c;">Συνέχεια</button>
      </form>
      
      <button type="button" id="clearall"style="margin-bottom: 8px; border-radius: 5px; background-color: #44cc7c; color: white; font-weight: bold; border-color: #44cc7c;">Ακύρωση όλων</button>
      
      </div>
<script>
//////////////////////////
let elements= document.getElementById("mytable").getElementsByTagName("select");
mystorage = JSON.parse(getCookie("mystorage"));

for (let i = 0; i < elements.length; i++) {
    for (let j = 0; j < mystorage.length; j++) {
      
      
      if ((mystorage[j][0] === elements[i].dataset.event) ) {
        
        
        elements[i].value = mystorage[j][1];
        
        // js inject text
        for(let n=0; n< document.getElementsByClassName("injected").length; n++){
          document.getElementsByClassName("injected")[n].innerText = elements[n].value * elements[n].dataset.cost;
          
        }
        }
    }
} 

console.log(mystorage);


//event delegate change
document.getElementById("mytable").addEventListener('change', event => {
  
  if(event.target.tagName === 'SELECT'){
    
    for(let n=0; n< document.getElementsByClassName("injected").length; n++){
      document.getElementsByClassName("injected")[n].innerText = elements[n].value * elements[n].dataset.cost;
      //Γίνεται κατα σειρά, επανεγγραφή όλων των τιμών του πίνακα οπότε δέν χρειαζόμαστε if για την ανάθεση των στοιχείων μεμονωμένα.
      mystorage[n]=([elements[n].dataset.event, elements[n].value]);
      setCookie("mystorage", JSON.stringify(mystorage), 1);
      
    }
    console.log(JSON.parse(getCookie("mystorage")));
  } 
    });



//event delegate click
document.getElementById("mytable").addEventListener('click', event => {
  if(event.target.tagName === 'A'){
    //remove specific event id value 
      for(let n=0; n<mystorage.length; n++){
        if (mystorage[n][0] === event.target.dataset.value){
          
          mystorage.splice(n, 1);
          console.log("splice storage");
          setCookie("mystorage", JSON.stringify(mystorage), 1);
        }
      }
              
  
          for(let z=0; z< document.getElementById("mytable").getElementsByTagName("tr").length; z++){
            if (document.getElementById("mytable").getElementsByTagName("tr")[z].id === event.target.dataset.value){
              //style.display = "none";
              //remove element
              document.getElementById("mytable").getElementsByTagName("tr")[z].remove();

              if (mystorage.length == 0 ){
                
                mystorage=[];
                setCookie("mystorage", JSON.stringify(mystorage), 1);
                

                window.location.href = "main.php";

              }
            }
          } 
        
    }
  });
  
  document.getElementById("gotoreceipt").addEventListener("click", function(){
        
        window.location.href = "receipt.php";
    });

  document.getElementById("clearall").addEventListener("click", function(){
    mystorage=[];
    
    setCookie("mystorage", JSON.stringify(mystorage), 1);
    

        window.location.href = "main.php";
    });
    /////////////////////////////////////////////////////////////////////////////////////////


    function setCookie(cname, cvalue, exdays) {
      var d = new Date();
      d.setTime(d.getTime() + (exdays*24*60*60*1000));
      var expires = "expires="+ d.toUTCString();
      document.cookie = cname + "=" + cvalue + ";" + expires  ;
      
    }

    function getCookie(cname) {
      var name = cname + "=";
      var decodedCookie = decodeURIComponent(document.cookie);
      var ca = decodedCookie.split(';');
      for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }
    
  
  </script>

</body>
</html> 
