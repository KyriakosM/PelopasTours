<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">  
  <link rel="stylesheet" href="staff.css">
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">  
  <title>PELOPAS TRAVEL</title>
  
  <style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

th {text-align:center;
}

</style>
  
  
</head>
<body>
  
<div class="imge"><img src="./photos/logostaff.png" alt=""></div>
<?php
      
      require_once 'connection.php';

        //event query
        // Prepare our SQL, preparing the SQL statement will prevent SQL injection.
        if ($stmt = $dbconn->prepare('SELECT * FROM event')) {
          $stmt->execute(); 
          $stmt->store_result();
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $count=$stmt->num_rows;
          $stmt->bind_result($e_id,$e_name,$e_desc,$e_cost);
          //statement fetch results
          while ($stmt->fetch()){
            // use column variables from binding
            $event_id[]=$e_id;
            $event_name[]=$e_name;
            $event_desc[]=$e_desc;
            $event_cost[]=$e_cost;
          }
        }
        
        //user query
        // Prepare our SQL, preparing the SQL statement will prevent SQL injection.
        if ($stmt = $dbconn->prepare('SELECT user_id, user_type_id, username, name, surname, telephone, address, email FROM user')) {
            $stmt->execute(); 
            $stmt->store_result();
          }
  
          if ($stmt->num_rows > 0) {
            // bind results
            $count2=$stmt->num_rows;
            $stmt->bind_result($u_id,$t_id,$u_user,$u_name,$u_sur,$u_tel,$u_add,$u_mail);
            //statement fetch results
            while ($stmt->fetch()){
              // use column variables from binding
              $user_id[]=$u_id;
              $type_id[]=$t_id;
              $u_username[]=$u_user;
              $u_firstname[]=$u_name;
              $user_surname[]=$u_sur;
              $user_tel[]=$u_tel;
              $user_address[]=$u_add;
              $user_email[]=$u_mail;
            }
          }

        //search by event id
        // Prepare our SQL, preparing the SQL statement will prevent SQL injection.
		
		
        if ($stmt = $dbconn->prepare('SELECT * FROM event
        where event_id=(?)')) {
            $stmt->bind_param('i', $_POST['inputevent02']);
            $stmt->execute(); 
            $stmt->store_result();
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $count3=$stmt->num_rows;
          $stmt->bind_result($ev_id, $ev_name, $ev_desc,$ev_cost);
          //statement fetch results
          while ($stmt->fetch()){
            // use column variables from binding
			$eve_id[]=$ev_id;
			$eve_name[]=$ev_name;
            $eve_desc[]=$ev_desc;
            $eve_cost[]=$ev_cost;
          }
        }
		else
		{
			$eve_name[]= $eve_desc[]="";
		}

        $stmt->close();
      ?>

      
  <!-- επικεφαλίδα -->
  <div class="container">
      <br>
          <hr style="height: 5px; background-color: lightgreen;     background-image:linear-gradient(to right, lightgreen, rgba(0, 0, 0, 0.85), lightgreen
          );">

      <?php echo '<p style="margin-left:171px; margin-top:-80px; background-color:#F8F8F8; color:black; "> ΔΙΑΧΕΙΡΙΣΗ PELOPAS TOURS: Καλως ήρθες ' . $_SESSION['name'] . ' !</p>'; ?>
      <form id="form3" method="post" action="logout.php">
                            
			  <button type="submit"  style="margin-left: 700px; margin-top: 3px;width:220px;" class="btn btn-primary koubi">Εξοδος</button>
	  </form>   
      
    </div>
	
	
	<p> Πωλήσεις</p>	  
	<br><br><br>
	 <button type="button"  style="margin-right: 7px; margin-top: 3px;width:220px;" id="myButton" class="btn btn-primary koubi"; >Πωλησεις εισιτηριων</button>
    <br><br><br><br>
         
	<hr class="grammi">	
	
	<!-- tab2 -->
	<br>
    <div class="tab">
		
      <?php
      // checkbox list 
      echo "<p> Τρέχοντες προορισμοί</p>";
      echo "<table><thead>";
      echo "<tr><th>Κωδικός</th><th>Όνομα</th><th>Περιγραφή</th><th>Τιμή</th></tr>";
      echo "</thead>";
      // Εμφάνιση χρηστών//
      for ($i=0;$i<$count;$i++){
        echo "<tr>". "<td>" . $event_id[$i] ."</td>" ."<td>".  $event_name[$i] ."</td>". "<td>" . $event_desc[$i] ."</td>". 
        "<td>" . $event_cost[$i] . "</td>" ."</tr>";
      }
      echo "</table>" ;
        ?>		
	
    </div>
    <br><br>
	<hr class="grammi">	
	


    <form id="form1" method="post" action="staff.php">
      <p> Μεταβολή υφιστάμενου προορισμού </p>
            <div class="form-group">
              <label for="inputevent02">Κωδικός</label>
              <input type="number" class="form-control" id="inputevent02" name="inputevent02" placeholder="Κωδικός από τον παραπάνω πίνακα">
            </div>
            <button type="submit"  style="margin-right: 7px; margin-top: 3px;width:220px;"class="btn btn-primary koubi">Αναζήτηση</button>
            <button type="reset" style="margin-right: 7px; margin-top: 3px;width:220px;" class="btn btn-secondary koubi">Καθαρισμoς</button>
          </form>
          <hr class="grammi">

<!-- --> 

    <form id="form1" method="post" action="updateevent.php">

            <div class="form-group">
            <label for="inputid">Κωδικός</label>
            <!-- --> 
              <input type="number" class="form-control" maxlength="11"id="inputid" name="inputid" value="<?php echo $eve_id[0] ?>" readonly>

              <label for="inputevent">Όνομα</label>
              <!-- --> 
              <input type="text" class="form-control" maxlength="45"id="inputevent" name="inputevent" value="<?php echo $eve_name[0] ?>">

              <label for="inputdesc">Περιγραφή</label>
              <!-- --> 
              <input type="text" class="form-control" maxlength="200"id="inputdesc" name="inputdesc" value="<?php echo $eve_desc[0] ?>">

              <label for="inputcost">Τιμή</label>
              <!-- --> 
              <input type="number" class="form-control" maxlength="20"id="inputcost" name="inputcost"  value="<?php echo $eve_cost[0] ?>" min="0" >
            </div>
            <button type="submit" style="margin-right: 7px; margin-top: 3px;width:220px;"class="btn btn-primary koubi">Καταχωρηση</button>

          </form>
  
  
          <hr style="color: red; width: 5px;">

    <form id="form1" method="post" action="addevent.php">
      <p> Καταχώρηση νέου προορισμού</p>
            <div class="form-group">
              <label for="inputevent">Όνομα</label>
              <input type="text" class="form-control" maxlength="45" id="inputevent" name="inputevent" placeholder="Όνομα">

              <label for="inputdesc">Περιγραφή</label>
              <input type="text" class="form-control" maxlength="200" id="inputdesc" name="inputdesc" placeholder="Περιγραφή">

              <label for="inputcost">Τιμή</label>
              <input type="number" class="form-control" maxlength="10" id="inputcost" name="inputcost" placeholder="Τιμή" min="0">
            </div>
            <button type="submit" style="margin-right: 7px; margin-top: 3px;width:220px;"class="btn btn-primary koubi">Καταχωρηση</button>
            <button type="reset" style="margin-right: 7px; margin-top: 3px;width:220px;"class="btn btn-secondary koubi">Καθαρισμός</button>
          </form>

          <hr class="grammi">
          


          <script>
              document.getElementById("myButton").onclick = function () {
                  location.href = "reportorderline.php";
              };
          </script>
    <hr class="grammi">
        
          <!--  -->
    <div class="tab" style="margin-top: 100px;">
      <?php
      // checkbox list 
      echo "<p> Χρήστες συστήματος</p>";
      echo "<table><thead>";
      echo "<tr><th>Κωδικός χρήστη</th><th>Είδος</th><th>Username</th><th>Επίθετο</th><th>Όνομα</th><th>Τηλέφωνο</th><th>Διεύθυνση</th><th>E-mail</th></tr>";
      echo "</thead>";
      // Εμφάνιση χρηστών//
      for ($i=0;$i<$count2;$i++){
        echo "<tr>". "<td>" . $user_id[$i] ."</td>" ."<td>".  $type_id[$i] ."</td>". "<td>" . $u_username[$i] ."</td>". 
        "<td>" . $user_surname[$i] ."</td>". "<td>" . $u_firstname[$i] ."</td>". 
        "<td>" . $user_tel[$i]  ."</td>". "<td>" . $user_address[$i] ."</td>". "<td>" . $user_email[$i] . "</td>" ."</tr>";
      }
      echo "</table>" ;
        ?>
    </div><br>

  	<hr class="grammi">	      

<div class="container"style="margin-left: -18px;">
<form id="form2" method="post" action="addstaff.php">
<p > Καταχώρηση νέου μέλους προσωπικού</p>

    <div class="form-group">
      <label for="inputUser">Όνομα χρήστη</label>
      <input type="text" class="form-control" maxlength="45" id="inputUser" name="inputUser" placeholder="username">
    </div>
    <div class="form-group">
      <label for="inputPassword">Κωδικός Password</label>
      <input type="password" class="form-control" maxlength="260" id="inputPassword" name="inputPassword" placeholder="password">
    </div>
	<div class="form-group">
      <label for="inputSurname">Επίθετο</label>
      <input type="text" style= "text-transform: uppercase" class="form-control" maxlength="45"id="inputSurname" name="inputSurname" placeholder="Surname">
    </div>
    <div class="form-group">
      <label for="inputName">Όνομα</label>
      <input type="text" style= "text-transform: uppercase" class="form-control" maxlength="45" id="inputName" name="inputName" placeholder="Name">
    </div>
    <div class="form-group">
      <label for="inputAddress">Διεύθυνση</label>
      <input type="text" class="form-control" maxlength="50"id="inputAddress" name="inputAddress" placeholder="Address">
    </div>
    <div class="form-group">
      <label for="inputEmail">E-mail</label>
      <input type="text" class="form-control" maxlength="45"id="inputEmail" name="inputEmail" placeholder="E-mail">
    </div>
	 <div class="form-group">
      <label for="inputTelephone">Τηλέφωνο</label>
      <input type="number" class="form-control" maxlength="10"id="inputTelephone" name="inputTelephone" placeholder="Telephone">
    </div>
    
    <button type="submit" class="koubi" style="margin-right: 7px; margin-top: 3px;width:220px;" class="btn btn-primary">Καταχωρηση</button>
    <button type="reset"  class="koubi"  style="margin-right: 7px; margin-top: 3px; width:220px;"class="btn btn-secondary">Καθαρισμος</button>
  </form>
  <br>
 
</div><br><br>

	<hr class="grammi">	

<br>
<p >Επικοινωνία</p>
<br><br>
<button type="button" id="messagebtn"style="width:220px; margin-bottom: 150px;" class="btn btn-default koubi">Μηνυματα</button>
    <script>
      document.getElementById("messagebtn").addEventListener("click", function(){
  
    window.location.href = "adminmsg.php";
    });
    </script>


	<hr class="grammi">	


</body>
</html>
      