<!DOCTYPE html>
<html>
    <head>
        <title>ADVENTURE TRAVEL</title>
        <meta charset="utf-8">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <script src="https://kit.fontawesome.com/yourcode.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">     
         <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@1,700&display=swap" rel="stylesheet"> 
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet"> 
    </head>

    <body>
      <!--------------  header ----------------->
      <header>
        <nav class="navbar navbar-expand-md navbar-dark navbar-custom">
  <a class="navbar-brand notthis" href="index.php"><img id="mainlogo" src="./photos/logo.png" alt="Logo" ></a>

   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation" >
    <span class="navbar-toggler-icon ic"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav" >
      <li class="nav-item active">
        <a class="nav-link navbar-text notthis" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link navbar-text notthis" href="pricing.html" style="color:white;">Shop</a>
      </li>
      <li class="nav-item">
        <a class="nav-link navbar-text notthis" href="pricing.html"style="color:white;">Trips</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle navbar-text notthis"style="color:white;" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Sign In
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item notthis" href="#" id="signin">Sign In</a>
          <a class="dropdown-item notthis" href="#" id="goToNewAcc">Sign Up</a>
        </div>
        <li class="nav-item custom-text"style="margin-left: 211px;">
          <a class="nav-link nav-about navbar-text notthis" aria-current="page" href="systeminfo.html"style="color:white;">About</a>
        </li>
      </li>
    </ul>
  </div>
</nav>

    <p id="auxiliaryText"></p>

    <!------- header animations ------->
    <p class="banner1">Μοναδικές εμπειρίες για όλη την οικογένεια</p>
    <p class="banner2">ADVENTURE Tours</p>
    <button class="banner-btn"onclick="window.location.href='http://localhost/pelopas/newaccount.php'">Εγγραφειτε τωρα!</button>
  
    </header>
    <!------------------ Special Team ----------------->
    <section id="section-special">
  <h2 class="special1" style="text-transform: uppercase;">Our Guide</h2>
    <hr width="120" class="line">
    <p class="special2" style="margin-bottom:2.2rem;">Η εξειδικευμένη μας ομάδα θα αναλάβει την ξενάγηση σας <br>στα ωραιότερα μέρη της   Πελοποννήσου </p>
     
    <div class="specialphotos3">
      <a href="systeminfo.html"><i class="fa fa-search lenphoto"style="font-size:35px;"></i></a>
      <img class="ourteam1" src="./photos/kyriakos.jpg" alt="kyriakos">
      <a href="systeminfo.html"><div class="lenphoto2">Κυριάκος Μάργαρης</div></a>
    </div>
    </section>
   
     <!----------- Carousel Photos ----------->
 
    <div id="carouselExampleIndicators"data-interval="7500" class="carousel slide car" data-pause="false" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="./photos/oikismoi.jpg" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
    <h2 class="h2car">Επίσκεψη Παραδοσιακών Οικισμών και χωριών</h2>
    <p class="pcar">Γνωρισε απο κοντα μερικους απo τους ομορφοτερους οικισμους της Ελλαδας</p>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="./photos/taygetos.jpg" alt="Second slide">
      <div class="carousel-caption d-none d-md-block">
    <h2 class="h2car">Συναρπαστική Ορειβασία στον Ταύγετο</h2>
    <p  class="pcar">...και πεζοπορια σε πολλα βουνα και μονοπατια της Πελοποννησου</p>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="./photos/roadtrip.jpg" alt="Third slide">
      <div class="carousel-caption d-none d-md-block">
    <h2 class="h2car">Καλοκαιρινό Roadtrip στην Πελοπόννησο..</h2>
    <p class="pcar">Eνα Καλοκαιρινo road-trip Που θα σας μεινει αξεχαστο!</p>
  </div>
 
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


    <!------------ Map ------------->
<div class="map">
<img class="pelop" src="./photos/map.jpg" width="60%" height="auto" alt="Workplace" usemap="#workmap" width="400" height="379">
<h4 class="h4paragraph" style="position: absolute; top: 42px; left: 135px;">Αξιοπιστία</h4>
<p class="Maparagraph"style="position: absolute; top: 72px; left: 135px;">Πάνω από 4.000 πεζοπορίες <br>τα τελευταία 3 χρόνια..</p>
<h4 class="h4paragraph" style="position: absolute; top: 196px; left: 135px;">Εμπιστοσύνη</h4>
<p class="Maparagraph"style="position: absolute; top: 226px; left: 135px;">Σταθερά μέσος όρος πάνω από 4,9 <br>απ'τις βαθμολογίες των μελών μας!</p>
<h4 class="h4paragraph" style="position: absolute; top: 348px; left: 135px;">Ασφάλεια</h4>
<p class="Maparagraph"style="position: absolute; top: 378px; left: 135px;">Μέσα από την τεράστια εμπειρία μας<br> με την πιο "Special Team" της Πελ/νήσου</p>

<h4 class="h4paragraph m" style="position: absolute; top: 50px; right: 125px;">Εμπειρίες</h4>
<p class="Maparagraph"style="position: absolute; top: 80px; right: 125px; text-align: right;">Ζήσε αξέχαστες στιγμές με την <br>παρέα σου στα πιο όμορφα μέρη <br>της Πελ/νήοσυ</p>
<h4 class="h4paragraph m" style="position: absolute; top: 200px; right: 125px;">Επικοινωνία</h4>
<p class="Maparagraph"style="position: absolute; top: 230px; right: 125px;text-align: right;">24/24 - 7/7 είμαστε διαθέσιμοι <br>στο τηλ/κό μας κέντρο!</p>
<h4 class="h4paragraph m" style="position: absolute; top: 350px; right: 125px;">Προτάσεις</h4>
<p class="Maparagraph"style="position: absolute; top: 380px; right: 125px;text-align: right;">Θες να "φτιάξεις" τη δικιά σου διαδρομή;<br> Ελα σε επικοινωνία μαζί μας άμεσα!</p>
</div>

<map name="workmap">
  <area shape="circle" coords="220,81,18" onclick="myFunction()">
  <area shape="circle" coords="232,160,18" onclick="myFunction2()">
  <area shape="circle" coords="275,215,18" onclick="myFunction3()">
  <area shape="circle" coords="216,348,18" onclick="myFunction4()">
</map>


<script>
function myFunction() {
  alert("Σκι και'extreme sports' στα υπέροχα Καλάβρυτα! ");
}
function myFunction2() {
  alert("Aπόδραση στα ομορφότερα μονοπάτια στα βουνά της Βιτίνας!!");
}
function myFunction3() {
  alert("Τι πιο όμορφο αυτό το ΣΚ από μια μονοήμερη εκδρομή στην γραφική Τρίπολη!");
}
function myFunction4() {
  alert("Δείτε από πρώτο χέρι πως παράγεται το αξεπέραστο κρασί της Καλαμάτας και απολαύστε τις ομορφιές της Πόλης!");
}
</script><br><br><br><br><br><br><br>

 
      <!-----------  Last image castle ---------->
<div class="kardamili">
  <h2 style="font-weight:bold;text-align: center; color: #F0F0F0; margin-top: 90px; text-shadow: 2px 2px #000; font-family: 'EB Garamond', serif;">Aνακάλυψε κάθε γωνιά της Πελοποννήσου</h2>
     <button style="margin-top:38px;"class="banner-btn" onclick="window.location.href='http://localhost/pelopas/newaccount.php'">ΕΓΓΡΑΦΕΙΤΕ ΤΩΡΑ!</button>
</div>



<!------------ Animations on view --------------->

 <section id="eshop">
<h2 class="special1 anim1" style="text-transform: uppercase;">Xρειαζεστε εξοπλισμο;</h2>
    <p class="special2 anim2" style="font-size:1.5rem; color:lightgreen; text-shadow: 1px 1px 0px  black, -1px -1px 0px  black, 1px -1px 0px  black, -1px 1px 0px  black;">...ότι θέλετε ένα "κλικ" μακρυά!</p>
    <button class="banner-btn"onclick="window.location.href='http://localhost/pelopas/newaccount.php'" style="margin-top:45px;">-20% Για online αγορές</button>

    </section>






    <!---------- Some Logos ------------>
    <div class="big">
<div class="s1"style="margin-top: 15px;"><img src="./photos/s1.png" alt=""></div>
<div class="s1"><img src="./photos/s2.png" alt=""></div>
<div class="s1"style="margin-top: -18px;"><img src="./photos/s3.png" alt=""></div>
<div class="s1"style="margin-top: 15px;"><img src="./photos/s4.png" alt=""></div>
    </div>
<br>
<br>

      <!----------   bottom   --------->
<div class="profooter"></div>
<div class="footer">
  <div class="inside-footer">
    <img width="150" style="margin-left: -6px;" src="./photos/logo2.png" alt="">
    <p class="pfoot">Για οποιαδήποτε απορία, διευκρίνιση <br>  ή πρόταση μη διστάσετε να επικοι-<br>  νωνήσετε μαζί μας καθημερινά <br> από τις 9:00πμ εας και τις 8:30μμ</p><br>
    <i class="fa fa-phone fa-lg pfoot2"></i><span class="pfoot2" style="margin-left: 10px;">697 00 00 000</span><br>
    <i class="fa fa-map-marker fa-lg pfoot2"></i><span class="pfoot2" style="margin-left: 10px;"> Μ. Καραολή & Α. Δημητρίου 80</span><br>
    <i class="fa fa-facebook-square fa-lg pfoot2"></i><span class="pfoot2" style="margin-left: 10px;">Βρείτε μας στο Facebook</span></div>
   
	<div class="inside-footer2">
      <input class="in" type="text" name="" placeholder="Όνομα"><br><br>
      <input class="in" type="text" name="" placeholder="Email"><br><br>
      <textarea name="" id="" cols="14" rows="3" placeholder="Γράψτε το μήνυμά σας εδώ."></textarea><br><br>	
      <button type="button" style="width:150px; margin-top: 19px; color: lightgreen; border-color: lightgreen;"  class="btn btn-outline-success bb">Αποστολή</button>
	</div>
	
		
    <div class="inside-footer3">
      <p class="pfoot2" style="margin-left: 10px; margin-bottom: 20px; ">Νέες Προσφορές</p>
      <p class="pfoot"style="margin-left: 10px;">Από αρχές του μήνα έκπτωση <br> 40% για αγορές άνω των 50 ευρώ!</p>
      <p class="pfoot2" style="margin-left: 10px; margin-bottom: 20px;">Ακούμε τις προτάσεις σας</p>
      <p class="pfoot"style="margin-left: 10px;">Απολύτως εξατομικευμένα προγράμματα<br> εκδρομών σύμφωνα με τις ανάγκες σας!</p>
      <p class="pfoot2" style="margin-left: 10px; margin-bottom: 20px;">Nέα πακέτα</p>
      <p class="pfoot"style="margin-left: 10px;">Μείνετε συντονισμένοι για νεα πακέτα<br>και προσφορές που ανακοινώνονται <br>συνεχώς</p>    
    </div>
    
    <div class="inside-footer4">
      <i style="margin-right: 4px;" class="fa fa-twitter pfoot2"></i>
      <i style="margin-right: 4px;" class="fa fa-instagram pfoot2"></i>
      <i style="margin-right: 4px;" class="fa fa-pinterest pfoot2"></i>
      <i style="margin-right: 4px;" class="fa fa-google pfoot2"></i>
    </div>

</div>
 <div style="padding:20px;background-color: #3f4547; margin-top: 5px; height: 105px;" >
      <a role="button" class="fake" id="goToContact"></a>
        <h3 class="fake"></h3>
        <button type="button" class="btn btn-primary fake" id="goToNewAcc"></button>
        <div class="ff">
        <h5 style="text-align: center;margin-top: -9px; color: #181818; font-family: Ubuntu;">- Διαχείριση -</h5>
        <button style="display:block;margin-left:auto;margin-right:auto;"type="button" class="btn btn-dark" id="staffentrance">Είσοδος</button></div>
 </div>


		<!-------- create padding --------->
		
        <script>

          // add event listener on click
        document.getElementById("goToNewAcc").addEventListener("click", function(){
          //redirect to new user creation page
            window.location.href = "http://localhost/pelopas/newaccount.php";
        });

        //redirect to staff entrance page
        document.getElementById("staffentrance").addEventListener("click", function(){
            window.location.href = "http://localhost/pelopas/staffentrance.php";
        });

           // ready to inject html code with js
          let text1= '<h3>Επαναφορά κωδικού πρόσβασης</h3>' +
          '<form action="mailto:kyriakosmgr@gmail.com" method="post" enctype="text/plain">' +
            '<div class="form-group">' +
              '<label for="name">Επώνυμο</label>' +
              '<input type="text" class="form-control" name="name">' +
            '</div>' +
            '<div class="form-group">' +
              '<label for="email">Email</label>' +
              '<input type="text" class="form-control" name="email">' +
            '</div>' +
            '<div class="form-group">' +
              '<label for="comment">Σχόλια</label>' +
              '<input type="text" class="form-control" name="comment" size="50">' +
            '</div>' +
              '<input type="submit" class="btn btn-primary" value="Αποστολή">' +
             '<input type="reset" class="btn btn-secondary" value="Ακύρωση">' +
           '</div>' +
          '</form>'

          let text2=
          '<form id="form1" method="post" action="authenticate.php">' +
            '<div class="form-group">' +
              '<label style=" text-shadow: 1px 1px black;margin-top:40px; margin-left:30px; font-size:1.1rem; font-weight:bold; color:white;"for="inputEmail">Όνομα Χρήστη</label>' +
              '<input type="text" style="margin-left:30px; width:250px;" class="form-control" id="inputUser" name="inputUser" placeholder="username">' +
            '</div>' +
            '<div class="form-group">' +
              '<label style="margin-top:10px; text-shadow: 1px 1px black; margin-left:30px;font-size:1.1rem; font-weight:bold; color:white;" for="inputPassword">Κωδικός</label>' +
              '<input type="password" style="margin-left:30px; width:250px;"class="form-control" id="inputPassword" name="inputPassword" placeholder="password">' +
            '</div>' +
            '<button type="submit" class="koubi" style=" margin-top:12px; margin-left:30px; margin-right:20px;"class="btn btn-primary">Εισοδος</button>' +
              '<button type="reset" class="koubi" style=" margin-top:12px;"class="btn btn-secondary">Καθαρισμος</button>' +
              '</form>'
              

          // add event listener on click
        document.getElementById("goToContact").addEventListener("click", function(){
          //redirect to new user creation page
          document.getElementById("auxiliaryText").innerHTML= text1;
        });
        document.getElementById("signin").addEventListener("click", function(){
          //redirect to new user creation page
          document.getElementsByClassName('banner1')[0].style.visibility = 'hidden';
          document.getElementsByClassName('banner2')[0].style.visibility = 'hidden';
          document.getElementsByClassName('banner-btn')[0].style.visibility = 'hidden';
          document.getElementById("auxiliaryText").innerHTML= text2;
        });
         
        </script>

<?php



?>

 <!--------- Bootstrap JS --------->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
</html>