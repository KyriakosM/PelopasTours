<!DOCTYPE html>
<html>
    <head>
        <title>PELOPAS TRAVEL</title>
        <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">  
		<link rel="stylesheet" href="staff.css">
		<link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet">
		<link rel="preconnect" href="https://fonts.gstatic.com">
		<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">  
		
    </head>
    <body>
	
			<form>
	        <button type="button" style="margin-top:10px;margin-right: 700px;width:250px;"class="btn btn-primary koubi" id="mybtn">Επιστροφη</button><!-- καλει javascript-->	
		</form>
		    <script>
              document.getElementById("mybtn").onclick = function () {
                  location.href = "staff.php";
              };
          </script>
	
        <?php
        
        //login details
        require_once 'login.php';
        $dbconn = mysqli_connect("$db_hostname", "$db_username", "$db_password", "$db_database");
        if (!$dbconn){
            die('Could not connect: ' . mysqli_error());
        }

        //define charset of the connection for Greek language
        mysqli_set_charset($dbconn, "utf8");
        //use of html form name parameter to access post data
        ///// mike changes /////    
        if (empty($_POST['inputUser'])  || empty($_POST['inputPassword']) || empty($_POST['inputSurname']) || empty($_POST['inputName']) 
            || empty($_POST['inputAddress']) || empty($_POST['inputEmail']) || empty($_POST['inputTelephone']) ){

                exit('Παρακαλώ συμπληρώστε όλα τα πεδία!');
        }
		
		if (preg_match("/[^a-zΑ-Ζ\s-]/i", ($_POST['inputName']))){
			exit('Δεν επιτρέπονται αριθμητικά ψηφία, τονισμός ή άλλα σύμβολα στο Όνομα.'); 
		}
		if (preg_match("/[^a-zΑ-Ζ\s-]/i", ($_POST['inputSurname']))){
			exit('Δεν επιτρέπονται αριθμητικά ψηφία, τονισμός ή άλλα σύμβολα στο Επίθετο.'); 
		}
		
		if (!filter_var(($_POST['inputEmail']), FILTER_VALIDATE_EMAIL)) {
			exit('H διεύθυνση Ε-mail δεν είναι έγκυρη!');
		}
		if(strlen($_POST['inputTelephone']) != 10){
			exit('Εισάγετε 10-ψήφιο τηλεφωνικό αριθμό.');  
		}
        
        // check if user already exists 
        // prevent SQL injection
        if ($stmt = $dbconn->prepare('SELECT username FROM user WHERE username = ?')) {
            // Bind parameters (s = string, i = int), in our case the username is a string so we use "s"
            $stmt->bind_param('s', $_POST['inputUser']);
            $stmt->execute();
            // Store the result so we can check if the account exists in the database.
            $stmt->store_result();
        }


        if ($stmt->num_rows > 0) {
            echo "<pre> 
                Ενημέρωση: Το username που υποβλήθηκε χρησιμοποιείται ήδη,
                παρακαλώ χρησιμοποιήστε διαφορετικό username για την εγγραφή.
                </pre>";

        }else{
            // insert new user to database
            if ($stmt = $dbconn->prepare('insert into user(username,password,user_type_id, surname, name, address, email, telephone) 
                values (?,?,?,?,?,?,?,?)')) {
                // hash password function, how to store into mysql database
                $hash = password_hash($_POST['inputPassword'], PASSWORD_DEFAULT);
                // Bind parameters (s = string, i = int), in our case the username is a string so we use "s"
                //Παίρνουμε ώς δεδομένο ότι απο αυτή τη λειτουργία καταχωρούνται σταθερά μονο STAFF
                // CATEGORY 6
                $usertype=6;
                $stmt->bind_param('ssissssi', $_POST['inputUser'],$hash,$usertype, $_POST['inputSurname'], $_POST['inputName'], $_POST['inputAddress'], $_POST['inputEmail'], $_POST['inputTelephone']);
                $stmt->execute();
                // Store the result 
                $stmt->store_result();
                
                echo "<pre>
                    Η καταχώρηση του νέου χρήστη πραγματοποιήθηκε επιτυχώς.
                    </pre>";
            }
        }

        $stmt->close();


        ?>

		
    </body>
</html>