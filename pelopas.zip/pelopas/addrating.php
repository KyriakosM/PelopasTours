<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rating</title>
</head>

<body>
  <?php
        
        //session_start();
        require_once 'greetinguser.php';

        //use of html form name parameter to access post data
        if (empty($_POST['inputeventid']) || empty($_POST['inputmark']) || empty($_POST['inputcomm'])) {
          exit('<h3 style="text-align:center; margin-top: 2%;font-size:2.3rem; color:white; text-shadow: 0 0 25px red;"><b>- Παρακαλούμε συμπληρώστε όλα τα πεδία!-</b></h3><br><p style="text-align:center;">Επιλέξτε Κεντρική Σελίδα για να συνεχίσετε</p>');
        }

        

        // ελέγχουμε άν ο συγκεκριμένος χρήστης έχει παρακολουθήσει το εν λόγω event προκειμένου να τοποθετήσει την κριτική
        if ($stmt = $dbconn->prepare('select user.user_id from order_line
        inner join customer_order
        on customer_order.customer_order_id = order_line.customer_order_id
        inner join user
        on user.user_id = customer_order.user_id
        where order_line.event_id = (?) and user.user_id = (?)')) {
          //s = string i= int d=double
        $stmt->bind_param('ii', $_POST['inputeventid'], $_SESSION['id']);
        $stmt->execute(); 
        $stmt->store_result(); 
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $stmt->bind_result($u_usercheck);
          $stmt->fetch();
          $user_check_id=$u_usercheck;
          
        }else{
          exit('<h3 style="text-align:center; margin-top: 2%;font-size:2.3rem; color:white; text-shadow: 0 0 25px red;"><b>- Δέν έχετε συμμετάσχει στη συγκεκριμένη δραστηριότητα -</b></h3><br><p style="text-align:center;">Επιλέξτε Κεντρική Σελίδα για να συνεχίσετε</p>');
        }

        

        $datetime = date('Y-m-d H:i:s');
          if ($stmt = $dbconn->prepare('INSERT INTO rating(user_id,event_id,rate,description,date) VALUES (?,?,?,?,?)')) {
              //s = string i= int d=double
            $stmt->bind_param('iiiss', $_SESSION['id'], $_POST['inputeventid'],$_POST['inputmark'],$_POST['inputcomm'], $datetime);
            $stmt->execute(); 

            exit('<h3 style="text-align:center; margin-top: 2%;font-size:2.3rem; color:white; text-shadow: 0 0 25px red;"><b>- Σας ευχαριστούμε για την αξιολόγησή σας! -</b></h3><br><p style="text-align:center;">Επιλέξτε Κεντρική Σελίδα για να συνεχίσετε</p>');

        }else{
          exit('<h3 style="text-align:center; margin-top: 2%;font-size:2.3rem; color:white; text-shadow: 0 0 25px red;"><b>- Ανεπιτυχής προσπάθεια καταχώρησης -</b></h3><br><p style="text-align:center;">Επιλέξτε Κεντρική Σελίδα για να συνεχίσετε</p>');
            
        }

        
        $stmt->close();
      ?>



</body>
</html>
      




