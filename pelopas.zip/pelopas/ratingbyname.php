<!DOCTYPE html>
<html lang="en">
<head>

  <style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

th {text-align:center;
}

</style>
</head>

<body>


      <?php
        //session_start();
        require_once 'connection.php';
      
        //use of html form name parameter to access post data
        if (empty($_POST['inputevent02'])) {
            exit('Παρακαλώ συμπληρώστε όλα τα πεδία!');
    }
          
          if ($stmt = $dbconn->prepare('SELECT user.username, event.event_name, rating.rate, rating.description, rating.date 
          from rating
          inner join user 
          on user.user_id = rating.user_id
          inner join event 
          on event.event_id = rating.event_id 
          where event_name = (?)')) {
            $stmt->bind_param('s', $_POST['inputevent02']);
            $stmt->execute(); 
            $stmt->store_result();
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $counttwo=$stmt->num_rows;
          $stmt->bind_result($u_user,$e_name2,$r_rate,$r_desc,$r_date);
          //statement fetch results
          while ($stmt->fetch()){
            // use column variables from binding
            $user_username[]=$u_user;
            $event_name2[]=$e_name2;
            $rating_rate[]=$r_rate;
            $rating_desc[]=$r_desc;
            $rating_date[]=$r_date;
          }
        }else{
            exit('Δεν βρέθηκαν εγγραφές');
          }

        $stmt->close();
      ?>


      
  
   
<!--  -->
<div class="tab">
		
      <?php
      echo "<br><table><thead>";
      echo "<tr><th>Προορισμός</th><th>Χρήστης</th><th>Βαθμολογία</th><th>Σχόλια</th><th>Ημερομηνία</th></tr>";
      echo "</thead>";
      // Εμφάνιση αξιολογήσεων//
      for ($i=0;$i<$counttwo;$i++){
        echo "<tr>". "<td>" . $event_name2[$i] ."</td>" ."<td>".  $user_username[$i] ."</td>". "<td>" . $rating_rate[$i] ."</td>". 
        "<td>" . $rating_desc[$i] ."</td>". "<td>" . $rating_date[$i] ."</td>". "</td>" ."</tr>";
      }
      echo "</table>" ;
        ?>		
		
	
		
    </div>  
</body>
</html>	