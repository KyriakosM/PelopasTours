<!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PELOPAS TRAVEL</title>
  
  <style>
  
.koubi{
	padding: 0.7rem 1rem;
	border-radius: 5px;
	border: none;
	background-color: #44cc7c;
	text-transform: uppercase;
	color: white;
	font-weight: bolder;	
	cursor: pointer;
	width: 100px;
	
}
.koubi:hover{
	opacity: 0.7;
}
  
  
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

th {text-align:center;
}

</style>
  
  
</head>

<body>
  
<div class="imge"><img src="./photos/logostaff.png" alt=""></div>

  <?php

  //session_start();
  require_once 'connection.php';


?>


<div style="margin: 70px 0 80px 70px; ">
<!-- εισερχόμενα  -->

<p id="demo"></p>
  <br>
  <hr>
  <br>
<!-- απεσταλμένα  -->
<p id="demo2"></p>
  <br>
  <hr>
  <br>
  </div> 
 
     <form id="form3" method="post" action="logout.php">
        <button type="button" style="margin-top:10px;margin-right: 700px; width:250px;" class="btn btn-primary koubi" id="mybtn">Επιστροφη</button><!-- καλει javascript-->
        <button type="submit" style="margin-top:10px;width:250px;"class="btn btn-secondary koubi">Εξοδος</button>
    </form>  
	
    <script>
              document.getElementById("mybtn").onclick = function () {
                  location.href = "staff.php";
              };
          </script>

  
<!-- Δημιουργία νέου  -->
<div style=" border-radius:15px;margin-left:auto; margin-right:auto;padding:15px;width:460px; height: 320px; background-color: #44cc7c;text-align: center;">
<h2 style="letter-spacing: 1px; font-family: arial; color: white;text-shadow: -1px 0 black;">Δημιουργία νέου μηνύματος</h2>

<form id="form3" >

    <label for="user_id">Κωδικός παραλήπτη</label><br>
    <input type="text" class="form-control" id="user_id" name="user_id"style="box-shadow: 0 0 14px #44cc7c;" placeholder="Κωδικός χρήστη"><br>
    
    <label for="inbound_id">Κωδικός αντίστοιχου εισερχόμενου μηνύματος</label><br>
    <input type="text" class="form-control" id="inbound_id" name="inbound_id"style="box-shadow: 0 0 14px #44cc7c;" placeholder="Κωδικός εισερχόμενου"><br>  

    <label for="messagetxt">Κείμενο απάντησης</label><br>
    <textarea rows="4" cols="50" id="messagetxt" name="messagetxt" placeholder="Εισάγετε κείμενο εδώ" style="box-shadow: 0 0 14px #44cc7c;"></textarea>
  <br>
  <br>
  <button type="button" onclick="loadXML3()"style="margin-right: 5px; width: 140px;"class="btn btn-primary koubi">Αποστολη</button>
  <button type="reset"class="btn btn-primary koubi" style="width: 140px;">Καθαρισμός</button>
  
  <br><br><br><br><br>
</form>
<p id="demo3"></p>
</div>

<script>
///// run below ajax functions
loadXML();
loadXML2();

function loadXML() {
    var xhttp = new XMLHttpRequest();
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
          // Typical action to be performed when the document is ready:
          document.getElementById("demo").innerHTML = this.responseText;
        }
    };
    xhttp.open("POST", "adminmsgincoming.php", true);
    //xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhttp.send();
}

function loadXML2() {
    var xhttp = new XMLHttpRequest();
    
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
          // Typical action to be performed when the document is ready:
          document.getElementById("demo2").innerHTML = this.responseText;
        }
    };
    xhttp.open("POST", "adminmsgsent.php", true);
    //xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhttp.send();
}

function loadXML3() {
    var xhttp = new XMLHttpRequest();
    var data = document.getElementById("messagetxt").value;
    var data2 = document.getElementById("user_id").value;
    var data3 = document.getElementById("inbound_id").value;
    var vars = "messagetxt="+ data + "&user_id=" + data2 + "&inbound_id=" + data3 ;
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == XMLHttpRequest.DONE && this.status == 200) {
          // Typical action to be performed when the document is ready:
          document.getElementById("demo3").innerHTML = this.responseText;
        }
    };
    xhttp.open("POST", "adminmsgcreate.php", true);
    xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhttp.send(vars);
}

</script>

</body>

</html>