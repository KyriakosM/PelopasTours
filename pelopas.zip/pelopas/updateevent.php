<!DOCTYPE html>
<html>
    <head>
        <title>PELOPAS TRAVEL</title>
        <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">  
		<link rel="stylesheet" href="staff.css">
		<link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet">
		<link rel="preconnect" href="https://fonts.gstatic.com">
		<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">  
		
    </head>
    <body>
	
			<form>
	        <button type="button" style="margin-top:10px;margin-right: 700px;width:250px;"class="btn btn-primary koubi" id="mybtn">Επιστροφη</button><!-- καλει javascript-->	
		</form>
		    <script>
              document.getElementById("mybtn").onclick = function () {
                  location.href = "staff.php";
              };
          </script>


      <?php
        require_once 'connection.php';

        //use of html form name parameter to access post data 
        if ( empty($_POST['inputid']) || empty($_POST['inputevent']) || empty($_POST['inputdesc']) || empty($_POST['inputcost'])) {
            exit('Παρακαλώ συμπληρώστε όλα τα πεδία!');
    }
          
          if ($stmt = $dbconn->prepare('UPDATE event SET
              event_name = (?),
              event_desc = (?),
              event_cost = (?)
            WHERE
              event_id = (?) ')) {
              //s = string i= int d=double
            $stmt->bind_param('ssdi', $_POST['inputevent'],$_POST['inputdesc'],$_POST['inputcost'],$_POST['inputid']);
            $stmt->execute(); 

            exit('Τα στοιχεία ανανεώθηκαν επιτυχώς');

        }else{
            exit('Ανεπιτυχής προσπάθεια ανανέωσης στοιχείων');
        }

        
        $stmt->close();
      ?>

    </body>
</html>

