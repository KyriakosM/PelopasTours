<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"></head>
<style>
    body{padding: 0 50px 0 60px;}
    .padding{
        margin-left: 34%;

    }
</style>
  <?php

  //session_start();
  require_once 'greetinguser.php';


  ?>
<br>
<br>
<br>
<br>
<br>
<p id="cardtext">...</p>
<button type="button" id="checkout"style="margin-bottom: 8px;margin-left: 34%; border-radius: 5px; background-color: #44cc7c; color: white; font-weight: bold; border-color: #44cc7c;">Πληρωμή</button>
<button type="button" id="gotoreceipt"style="margin-bottom: 8px; border-radius: 5px; background-color: #44cc7c; color: white; font-weight: bold; border-color: #44cc7c;">Προηγούμενο βήμα</button>
<br>
<br>
<br>
<br>
<br>
<script>


let txt1= '<div class="padding">' +
    '<div class="row">' +
        '<div class="col-sm-6">' +
            '<div class="card">' +
                '<div class="card-header">' +
                    '<p>Πληρωμή με πιστωτική κάρτα</p>' +
                '</div>' +
                '<div class="card-body">' +
                    '<div class="row">' +
                        '<div class="col-sm-12">' +
                            '<div class="form-group">' +
                                '<label for="name">Όνομα κατόχου</label>' +
                                '<input class="form-control" type="text" id="name" style="text-transform: uppercase" name="name" placeholder="Cardholders name" >' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                    '<div class="row">' +
                        '<div class="col-sm-12">' +
                            '<div class="form-group">' +
                                '<label for="ccnumber">Αριθμός κάρτας</label>' +
                                '<div class="input-group">' +
                                    '<input class="form-control" type="number" id="creditNum" name= "creditNum" placeholder="Card number" >' +
                                    '<div class="input-group-append">' +
                                        '<span class="input-group-text">' +
                                            '<i class="mdi mdi-credit-card"></i>' +
                                        '</span>' +
                                    '</div>' +
                                '</div>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                    '<div class="row">' +
                        '<div class="form-group col-sm-4">' +
                            '<label for="ccmonth">Μήνας</label>' +
                            '<select class="form-control" id="ccmonth">' +
                                '<option></option>' +
								'<option>1</option>' +
                                '<option>2</option>' +
                                '<option>3</option>' +
                                '<option>4</option>' +
                                '<option>5</option>' +
                                '<option>6</option>' +
                                '<option>7</option>' +
                                '<option>8</option>' +
                                '<option>9</option>' +
                                '<option>10</option>' +
                                '<option>11</option>' +
                                '<option>12</option>' +
                            '</select>' +
                        '</div>' +
                        '<div class="form-group col-sm-4">' +
                            '<label for="ccyear">Έτος</label>' +
                            '<select class="form-control" id="ccyear">' +

                                '<option></option>' +
								'<option>2021</option>' +
                                '<option>2022</option>' +
                                '<option>2023</option>' +
                                '<option>2024</option>' +
                                '<option>2025</option>' +
                            '</select>' +
                        '</div>' +
                        '<div class="col-sm-4">' +
                            '<div class="form-group">' +
                                '<label for="cvv">CVV/CVC</label>' +
                                '<input class="form-control" id="cvv" type="number" placeholder="CVV">' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
                
            '</div>' +
        '</div>' +
    '</div>' +
'</div>';


	
document.getElementById("cardtext").innerHTML=txt1;

// go to transaction
document.getElementById("checkout").addEventListener("click", function(){
	
	
	var d1 = document.getElementById("name").value;
	
	var d2 = document.getElementById("creditNum").value;
	var l2 = d2.length;
	
	var d3 = document.getElementById("ccmonth").value;
	
	var d4 = document.getElementById("ccyear").value;
	
	var d = new Date();
	var m = d.getMonth();
	var y = d.getFullYear();
	
	var yd = d4-y;
		
	var d5 = document.getElementById("cvv").value;
	var l5 = d5.length;
	
	if (d1 == "")	{

		alert("Δεν έχετε συμπληρώσει όνομα κατόχου κάρτας.");
		return;
	}
	
	else if (!/^[a-zA-Z\s]*$/g.test(document.getElementById("name").value)){
		alert("Το όνομα κατόχου κάρτας περιλαμβάνει μόνο αλφαβητικούς χαρακτήρες.");
		return;
	}	
	
	else if (d2 == "")	{

		alert("Δεν έχετε συμπληρώσει αριθμό κάρτας.");
		return;
	}
	
	else if (l2 != 16)	{

		alert("O αριθμός κάρτας πρέπει να περιλαμβάνει 16 ψηφία.");
		return;
	}
	
	else if (d3 == "")	{

		alert("Δεν έχετε συμπληρώσει μήνα λήξης.");
		return;
	}
		
	else if (d4 == "")	{

		alert("Δεν έχετε συμπληρώσει έτος λήξης.");
		return;
	}
	
	else if (d5 == "")	{

		alert("Δεν έχετε συμπληρώσει κωδικό CVV.");
		return;
	}
	
	else if (l5 != 3)	{

		alert("O κωδικός CVV πρέπει να περιλαμβάνει 3 ψηφία.");
		return;
	}
	
	else if (yd = 0) {
						if(d3 <= m)	{

						alert("Ό μήνας λήξης της καρτας πρέπει να είναι μεταγενέστερος του τρέχοντος.");
						return;
		}
	}

	
	else {
		window.location.href = "transaction.php";
    }
});


    document.getElementById("gotoreceipt").addEventListener("click", function(){
        window.location.href = "receipt.php";
    });
/////////////////////////////////////////////////////////////////////////////////////////

</script>
<footer style="background-color: #1a1b1d; height: 130px; width: 100%;">
    <p style="text-align: center; color:white; padding-top: 60px;">® All rights Reserved by Kyriakos</p>
    </footer>

</html>