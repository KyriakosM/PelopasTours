<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="staff.css">
  <title>PELOPAS TRAVEL</title>
  <style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

th {text-align:center;
}

</style>
</head>
<body>


  
        <?php

        require_once 'connection.php';
        
        if ($stmt = $dbconn->prepare('select customer_order.customer_order_id, customer_order.customer_order_date, customer_order.order_total_cost, user.surname, user.name
        FROM customer_order
        inner join user
        on customer_order.user_id = user.user_id')) {
        
        $stmt->execute(); 
        $stmt->store_result(); 
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $count=$stmt->num_rows;
          $stmt->bind_result($myorderid,$mydate,$mytotalcost,$mysurname, $myname);
          //statement fetch results
          while ($stmt->fetch()){
            // use column variables from binding
            $cust_orderid[]= $myorderid;
            $cust_date[]= $mydate;
            $cust_totalcost[]= $mytotalcost;
            $user_surname[]= $mysurname;
            $user_firstname[]= $myname;
                  
          }
        }else{
          
          exit("Δέν βρέθηκαν εγγραφές");
        }

        //query 2 mike//
        if ($stmt = $dbconn->prepare('SELECT customer_order.customer_order_id, event_name, event_quant, customer_order_date,total_cost, user.surname, user.name
        FROM customer_order
        inner join order_line
        on customer_order.customer_order_id = order_line.customer_order_id
        inner join event
        on order_line.event_id = event.event_id 
        inner join user
        on customer_order.user_id = user.user_id ')) {
          //s = string i= int d=double
        
        $stmt->execute(); 
        $stmt->store_result(); 
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $count2=$stmt->num_rows;
          $stmt->bind_result($cο_corderid,$e_name,$e_quant,$co_date,$t_cost, $user_lastname, $user_name);
          //statement fetch results
          while ($stmt->fetch()){
            // use column variables from binding
            $custorder_orderid[]=$cο_corderid;
            $event_name[]=$e_name;
            $event_quant[]=$e_quant;
            $custorder_date[]=$co_date;
            $orderline_totalcost[]=$t_cost;
            $u_surname[]=$user_lastname;
            $u_name[]=$user_name;
          }
        }else{
          
          exit("Δέν βρέθηκαν εγγραφές");
        }
        
        $stmt->close();
      ?>


      
  <!-- επικεφαλίδα -->
  <div style="margin-top: -40px;" class="container">
      <br>
      
      <form id="form3" method="post" action="logout.php">
              <button type="button" style="margin-top:-200px;margin-right: 700px;width:220px;"class="btn btn-primary koubi" id="mybtn">Επιστροφη</button><!-- καλει javascript-->
              <button type="submit" style="margin-top:-200px;width:220px;"class="btn btn-secondary koubi">Εξοδος</button>
      </form>   
    </div>

    <script>
              document.getElementById("mybtn").onclick = function () {
                  location.href = "staff.php";
              };
          </script>

<!-- --> 
<p style="margin-top: -30px;">Πωλήσεις</p>
<div style="padding-left: 26%; margin-bottom: 85px;">
<?php
      echo "<table><thead>";
      echo "<tr><th style= text-align:center;>Αριθμός<br>παραγγελίας</th><th style= text-align:center;> Ημερομηνία</th><th style= text-align:center;>Συνολικό κόστος</th><th style= text-align:center;>Επώνυμο</th><th style= text-align:center;>Όνομα</th></tr>";
      echo "</thead>";
      // Εμφάνιση πωλήσεων//
      for ($i=0;$i<$count;$i++){
        echo "<tr>" . "<td>" . $cust_orderid[$i] ."</td>" . "<td>" .  $cust_date[$i] ."</td>". 
        "<td>" . $cust_totalcost[$i] ."</td>" ."<td>" . $user_surname[$i]  ."</td>" . 
        "<td>" . $user_firstname[$i]  ."</td>" ."</tr>" ;
      }
      echo "</table>" ;
?>
</div>
<div style="padding-left: 20%; margin-bottom: 85px;">
<?php
      echo "<table><thead>";
      echo "<tr><th style= text-align:center;>Κωδικός<br>Παραγγελίας</th><th style= text-align:center;> Προορισμός</th><th style= text-align:center;> Αριθμός<br> Εισιτηρίων</th><th style= text-align:center;> Ημερομηνία</th><th style= text-align:center;>Κόστος<br>ανά προορισμό</th><th style= text-align:center;>Επώνυμο</th><th style= text-align:center;>Όνομα</th></tr>";
      echo "</thead>";
      // query 2//
      for ($i=0;$i<$count2;$i++){
        echo "<tr>". "<td>" . $custorder_orderid[$i] ."</td>" ."<td>".  $event_name[$i] ."</td>". "<td>" . $event_quant[$i] ."</td>". 
        "<td>" . $custorder_date[$i]."</td>" ."<td>".$orderline_totalcost[$i]  . "</td>" ."<td>".$u_surname[$i]  . "</td>" . 
        "<td>".$u_name[$i]  . "</td>" . "</tr>";
      }
      echo "</table>" ;
?>
</div>
</body>
</html>
      
