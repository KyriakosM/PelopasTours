<!DOCTYPE html>
<html>
<head>
  <style>
  th{
    padding: 8px;
  }
</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"></head>
<?php
    

    
      //session_start();
      require_once 'greetinguser.php';

      $aux = json_decode($_COOKIE["mystorage"],true);

      for ($x = 0; $x < count($aux); $x++) {
          $arr[$x] = $aux[$x][0] ;
      }
      /*
      foreach($arr as $var){
        echo $var ;
    }
    */

      

      if (empty($arr)){
          exit("Δέν έχετε επιλέξει κάποιον προορισμό");
      }
        //event query receive data from post array 
        // χρησιμοποιήσαμε ήδη το  
        if ($stmt = $dbconn->prepare('SELECT * FROM event WHERE event_id IN (' . implode(',', $arr) . ')')) {
          $stmt->execute(); 
          $stmt->store_result();
        }

        if ($stmt->num_rows > 0) {
          // bind results
          $count=$stmt->num_rows;
          $stmt->bind_result($e_id,$e_name,$e_desc,$e_cost);
          //statement fetch results
          while ($stmt->fetch()){
            // use column variables from binding
            $event_id[]=$e_id;
            $event_name[]=$e_name;
            $event_desc[]=$e_desc;
            $event_cost[]=$e_cost;
          }
        }

        $stmt->close();

?>


<div style="text-align: center; margin-top: 90px; margin-bottom: 160px; width: 450px; margin-left:auto;margin-right:auto;height: 260px;background-color: rgba(0,0,0,0.1); ">
    <p style="letter-spacing:1px; font-size: 1.2rem; font-weight: bold; background-color: rgba(0,0,0,0.1);">Οι αγορές μου</p>
    <form id="form1" >
      <table id="mytable"border="1" style="margin-left: auto;margin-right: auto;"><thead>
      <tr><th>#</th><th>Προορισμός</th><th>Ποσό</th><th>Νόμισμα</th><th>Ατομα</th><th>Tιμή</th></tr>
      </thead>
      <?php
      // Εμφάνιση αποτελεσμάτων event
      for ($i=0;$i<$count;$i++){
        echo "<tr id=$event_id[$i] data-cost=$event_cost[$i]>". "<td>".  $event_id[$i] ."</td>" 
        ."<td>".  $event_name[$i] ."</td>" 
        ."<td>". $event_cost[$i] ."</td>" 
        ."<td>". " EUR" ."</td>" 
        ."<td class='quantity'>". "..." ."</td>" 
        ."<td class='injected'>". "..." ."</td>" ."</tr>";
      }
        ?>
        <tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>
        <tr><td></td><td></td><td></td><td></td><td style="text-align: left"><b>Σύνολο:</b></td><td id='total'>...</td></tr>
        </table>
      <br>
      <button type="button" id="gotocredit"style="margin-bottom: 8px; border-radius: 5px; background-color: #44cc7c; color: white; font-weight: bold; border-color: #44cc7c;">Πληρωμή</button>
      </form>
      
<button type="button" id="mybasket"style="margin-bottom: 8px; border-radius: 5px; background-color: #44cc7c; color: white; font-weight: bold; border-color: #44cc7c;">Προηγούμενο βήμα</button>
</div>
<script>

let mystorage = JSON.parse(getCookie("mystorage"));
console.log(mystorage);

// js inject text
let mysum=0;
let elements=document.getElementById("mytable").getElementsByTagName("tr");
//console.log(elements);
for(let n=0; n< document.getElementsByClassName("injected").length; n++){
  for(let i=0; i< mystorage.length; i++){
    //if id are the same then multiply quantity with cost for each line
    // use n+1 because get element also counts the <tr> head of the table!!!
    if(mystorage[i][0] == elements[n+1].id){
      
      document.getElementsByClassName("quantity")[n].innerText = mystorage[i][1];
      document.getElementsByClassName("injected")[n].innerText = mystorage[i][1] * elements[n+1].dataset.cost;
      mysum += mystorage[i][1] * elements[n+1].dataset.cost;
    }
  }
}
console.log(mysum);
document.getElementById("total").innerText = mysum;

    
    document.getElementById("mybasket").addEventListener("click", function(){
        window.location.href = "cart.php";
    });

    document.getElementById("gotocredit").addEventListener("click", function(){
        window.location.href = "yourcard.php";
    });

    /////////////////////////////////////////////////////////////////////////////////////////
    function setCookie(cname, cvalue, exdays) {
      var d = new Date();
      d.setTime(d.getTime() + (exdays*24*60*60*1000));
      var expires = "expires="+ d.toUTCString();
      document.cookie = cname + "=" + cvalue + ";" + expires  ;
    }

    function getCookie(cname) {
      var name = cname + "=";
      var decodedCookie = decodeURIComponent(document.cookie);
      var ca = decodedCookie.split(';');
      for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }
    
</script>
<footer style="background-color: #1a1b1d; height: 110px; width: 100%;">
      <p style="text-align: center; color:white; padding-top: 60px;">® All rights Reserved by Kyriakos</p>
    </footer>
</html>