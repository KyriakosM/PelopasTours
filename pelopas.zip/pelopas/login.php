<?php 
// login.php
$db_hostname = 'localhost';
$db_database = 'pelopas';//db name
$db_username = 'root';
$db_password = '';
?>
