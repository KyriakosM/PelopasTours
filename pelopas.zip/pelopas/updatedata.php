<?php
    
    //session_start();
    require_once 'connection.php';

    if ( empty($_POST['inputphone']) || empty($_POST['inputaddress']) || empty($_POST['inputemail']) ) {
        exit('Παρακαλώ συμπληρώστε όλα τα πεδία!');
    }
	
	if(strlen($_POST['inputphone']) != 10){
		exit('Εισάγετε 10-ψήφιο τηλεφωνικό αριθμό.');  
	}
	
	if (!filter_var(($_POST['inputemail']), FILTER_VALIDATE_EMAIL)) {
	exit('H διεύθυνση Ε-mail δεν είναι έγκυρη!');
	}
		
    //update by session username
    // Prepare our SQL, preparing the SQL statement will prevent SQL injection.
    if ($stmt = $dbconn->prepare('UPDATE user SET 
        telephone = (?),
        address = (?), 
        email= (?) 
        where user_id=(?)')){
        
            
            $stmt->bind_param('issi', $_POST['inputphone'], $_POST['inputaddress'], $_POST['inputemail'], $_SESSION['id']);
            $stmt->execute();    
            exit('Επιτυχής ενημέρωση στοιχείων');
        
        }else{
            exit('Ανεπιτυχής ενημέρωση στοιχείων');
        }

    $stmt->close();
?>

    
    
          