<!DOCTYPE html>
<html>
  <?php

  //session_start();
  require_once 'connection.php';

  if ( empty($_POST['messagetxt']) ) {
    exit('Παρακαλούμε συμπληρώστε κείμενο');
  }

  $datetime = date('Y-m-d H:i:s');
// Νέο μηνυμα 
  if ($stmt = $dbconn->prepare('insert into inbound(user_id,message,date) values (?,?,?);')){
    $stmt->bind_param('iss', $_SESSION['id'],$_POST['messagetxt'],$datetime);
    $stmt->execute(); 
      
    exit ("Το μήνυμά σας απεστάλη.<br>Επιλέξτε Κεντρική Σελίδα για να συνεχίσετε!");
      
  }


$stmt->close();

?>


</html>