<?php
    // We need to use sessions, always start sessions using the below code.
    session_start();
    
    // If the user is not logged in redirect to the login page...
    if (!isset($_SESSION['loggedin'])) {
        header('Location: index.html');
        exit;
    }
    
        //login details
    require_once 'login.php';
    $dbconn = mysqli_connect("$db_hostname", "$db_username", "$db_password", "$db_database");
    if (!$dbconn){
        die('Could not connect: ' . mysqli_error());
    }

    //define charset of the connection for Greek language
    mysqli_set_charset($dbconn, "utf8"); 
?>