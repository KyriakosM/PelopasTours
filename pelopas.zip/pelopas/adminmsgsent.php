<!DOCTYPE html>
<html>
  <?php

  //session_start();
  require_once 'connection.php';


// απεσταλμένα
if ($stmt = $dbconn->prepare('select outbound_id,inbound_id,user_id,message,date from outbound')){
  $stmt->execute(); 
  $stmt->store_result();   

  if ($stmt->num_rows > 0) {
    // bind results
    $count=$stmt->num_rows;
    $stmt->bind_result($out_id,$in_id,$u_id,$msg,$when);
    //statement fetch results
    while ($stmt->fetch()){
      // use column variables from binding 
      $outbound_id[]=$out_id;
      $inbound_id[]=$in_id;
      $user_id[]=$u_id;
      $message[]=$msg;
      $date[]=$when;
    }
  }else{
    exit ("Δεν υπάρχουν απεσταλμένα μηνύματα");
  }
}
$stmt->close();


?>
<h3>Απεσταλμένα μηνυματα</h3>
  <table id="mytable" >
  <thead>
  <tr><th>Κωδικός<br>PELOPAS</th><th>Κωδικός<br>εισερχομένου</th><th>Από<br>χρήστη</th><th>Απάντηση</th><th>Ημερομηνία</th></tr>
  </thead>
  <?php
  // Εμφάνιση αποτελεσμάτων 
  for ($i=0;$i<$count;$i++){
    echo "<tr>". "<td>".  $outbound_id[$i] ."</td>" 
    ."<td>".  $inbound_id[$i] ."</td>" 
    ."<td>".  $user_id[$i] ."</td>" 
    ."<td>". $message[$i] ."</td>" 
    ."<td>". $date[$i] ."</td></tr>";
  }
  ?>
  </table>
  



<script>


</script>


</html>